<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="utf-8">
  <meta content="width=device-width, initial-scale=1.0" name="viewport">
  <title>
    
  <?php echo e(isset($title) ? $title .'| '.__('auth.title') : __('auth.title')); ?>

  </title>
  <meta content="" name="description">
  <meta content="" name="keywords">
  <link href="<?php echo e(asset('backend/assets/img/favicon.png ')); ?>" rel="icon">
  <link href="<?php echo e(asset('backend/assets/img/apple-touch-icon.png')); ?>" rel="apple-touch-icon">
  <link href="https://fonts.gstatic.com" rel="preconnect">
  <link href="https://fonts.googleapis.com/css?family=Open+Sans:300,300i,400,400i,600,600i,700,700i|Nunito:300,300i,400,400i,600,600i,700,700i|Poppins:300,300i,400,400i,500,500i,600,600i,700,700i" rel="stylesheet">
  <link href="<?php echo e(asset('backend/assets/vendor/bootstrap/css/bootstrap.min.css')); ?>" rel="stylesheet">
  <link href="<?php echo e(asset('backend/assets/vendor/bootstrap-icons/bootstrap-icons.css')); ?>" rel="stylesheet">
  <link href="<?php echo e(asset('backend/assets/vendor/boxicons/css/boxicons.min.css')); ?>" rel="stylesheet">
  <link href="<?php echo e(asset('backend/assets/vendor/quill/quill.snow.css')); ?>" rel="stylesheet">
  <link href="<?php echo e(asset('backend/assets/vendor/quill/quill.bubble.css')); ?>" rel="stylesheet">
  <link href="<?php echo e(asset('backend/assets/vendor/remixicon/remixicon.css')); ?>" rel="stylesheet">
  <link href="<?php echo e(asset('backend/assets/vendor/simple-datatables/style.css')); ?>" rel="stylesheet">
  <link href="<?php echo e(asset('backend/assets/css/style.css')); ?>" rel="stylesheet">
          <!-- Alertify -->
  <link rel="stylesheet" href="<?php echo e(asset('/')); ?>backend/assets/vendor/alertify/alertify.core.css"/>
  <link rel="stylesheet" href="<?php echo e(asset('/')); ?>backend/assets/vendor/alertify/alertify.default.css" id="toggleCSS"/>

  <style type="text/css">
  .dataTable-wrapper{
      overflow: auto;
    }
  </style>
</head>
<body>
  <?php echo $__env->make('backend.layouts.header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
  <?php echo $__env->make('backend.layouts.sidebar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
  <?php echo $__env->yieldContent('main-content'); ?>
  <?php echo $__env->make('backend.layouts.footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
  <a href="#" class="back-to-top d-flex align-items-center justify-content-center"><i class="bi bi-arrow-up-short"></i></a>
  <script src="<?php echo e(asset('backend/assets/vendor/apexcharts/apexcharts.min.js')); ?>"></script>
  <script src="<?php echo e(asset('backend/assets/vendor/bootstrap/js/bootstrap.bundle.min.js')); ?>"></script>
  <script src="<?php echo e(asset('backend/assets/vendor/chart.js/chart.min.js')); ?>"></script>
  <script src="<?php echo e(asset('backend/assets/vendor/echarts/echarts.min.js')); ?>"></script>
  <script src="<?php echo e(asset('backend/assets/vendor/quill/quill.min.js')); ?>"></script>
  <script src="<?php echo e(asset('backend/assets/vendor/simple-datatables/simple-datatables.js')); ?>"></script>
  <script src="<?php echo e(asset('backend/assets/vendor/tinymce/tinymce.min.js')); ?>"></script>
  <script src="<?php echo e(asset('backend/assets/vendor/php-email-form/validate.js')); ?>"></script>
  <script src="<?php echo e(asset('backend/assets/js/main.js')); ?>"></script>
  <!-- Alertify -->
  <script src="<?php echo e(asset('/')); ?>backend/assets/vendor/alertify/alertify.min.js" type="text/jscript"></script>
 
  <?php if(session('success')): ?>
              
      <script type="text/javascript">
          var msg = '<?php echo e(session("success")); ?>';
          alertify.success(msg);
      </script>
  <?php elseif(session('flash_errors')): ?>
 
      <script type="text/javascript">
          var msg = '<?php echo e(session("flash_errors")); ?>';
          alertify.error(msg);
      </script>

  <?php elseif(session('errors')): ?>
 
      <script type="text/javascript">
        var msg = '<?php echo e(session("errors")); ?>';
        msg = JSON.parse(msg.replace(/&quot;/g, '"'));

        Object.keys(msg).forEach(function(index) {
            alertify.error(msg[index]);
        });
      </script>   

  <?php elseif(session('error')): ?>
 
      <script type="text/javascript">
          var msg = '<?php echo e(session("error")); ?>';
          alertify.error(msg);
      </script>    

  <?php endif; ?>

<script
  src="https://code.jquery.com/jquery-3.4.1.min.js"
  integrity="sha256-CSXorXvZcTkaix6Yvo6HppcZGetbYMGWSFlBw8HfCJo="
  crossorigin="anonymous"></script>
<link href="https://cdn.jsdelivr.net/npm/select2@4.0.12/dist/css/select2.min.css" rel="stylesheet" />
<script src="https://cdn.jsdelivr.net/npm/select2@4.0.12/dist/js/select2.min.js"></script>
<style type="text/css">
    .select2-dropdown.select2-dropdown--below,.select2-dropdown.select2-dropdown--above, .select2-results__option.select2-results__message{
        display: none;
    }
</style>
<script>
    $(document).ready(function() {

    $("select.dynamic-tags").select2({
      tags: true,
      multiple: true,
      placeholder: "Enter Pincode",
      createTag: (params) => {
        return {
          id: params.term,
          text: params.term,
        };
      }
    });
  })
</script>
  <?php echo $__env->yieldContent('script'); ?>

</body>
</html><?php /**PATH F:\xampp8.2\htdocs\mindufin\resources\views/backend/layouts/admin.blade.php ENDPATH**/ ?>