<?php $__env->startSection('main-content'); ?>
<main id="main" class="main">
    <div class="pagetitle">
        <h1><?php echo e($title ? $title : __('sidebar.send_notification')); ?></h1>
    </div>
    <section class="section">
        <div class="row">
            <div class="col-lg-1"></div>
            <div class="col-lg-10">
                <div class="card">
                    <div class="card-body">
                        <h5 class="card-title"> </h5>
                        <form action="<?php echo e(url('admin/send-notification')); ?>" method="POST" enctype="multipart/form-data" class="row g-3">

                        <?php echo csrf_field(); ?>
                            <div class="col-12">
                                <label for="jobtitle" class="form-label"><?php echo e(__('forms.title')); ?></label>
                                <input type="text" required name="title" class="form-control" id="page" placeholder="Enter <?php echo e(__('forms.title')); ?>" value="<?= !empty($getForEdit['title']) ? $getJobForEdit['title'] : '' ?>">
                            </div>
                            <br>
                            <div class="col-12">
                                <label for="jobtitle" class="form-label"><?php echo e(__('forms.body')); ?></label>
                                <textarea  required name="body" class="form-control" placeholder="Enter <?php echo e(__('forms.body')); ?>"></textarea>
                            </div>
                            <br>
                            
                            <div class="text-center"><button type="submit" class="btn btn-primary"><?php echo e(__('forms.submit')); ?></button> </div>
                        </form>
                    </div>
                </div>
            </div>
            <div class="col-lg-1"></div>
        </div>
    </section>
</main>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('backend.layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH F:\xampp8.2\htdocs\mindufin\resources\views/backend/notification/send-notification.blade.php ENDPATH**/ ?>