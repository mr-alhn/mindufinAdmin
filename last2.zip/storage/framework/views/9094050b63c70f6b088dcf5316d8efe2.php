<?php $__env->startSection('main-content'); ?>

<style type="text/css">
  a{
    position: relative;
  }
  .del{
    position: absolute;
    top: -20px;
    right: 0px;
  }
</style>
  <main id="main" class="main">
    <section class="section">
      <div class="row">
       
        <div class="col-lg-12">
          <div class="card">
            <div class="card-body">
              <h5 class="card-title"><?php echo e($title ? $title : "View All Banners"); ?></h5>
              <table class="table datatable">
                <thead>
                  <tr>
                    <th scope="col">#</th>
                    <th scope="col">Page</th>
                    <th scope="col">Images</th>
                    <th scope="col">Pincode</th>
                    <th scope="col">Action</th>
                  </tr>
                </thead>
                <tbody>
                  <?php if(!empty($records)): ?>
                  <?php $i="1"; ?>
                  <?php $__currentLoopData = $records; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $row): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                  <?php $page = $row->page; ?>
                  
                  <?php if(!empty($row->data)): ?>
                      <?php $__currentLoopData = $row->data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $data): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                      <tr>
                        <td scope="row"><?php echo e($i++); ?></td>
                        <td><?php echo e($page); ?></td>
                        <td>
                          <?php if(!empty($data->images)): ?>
                            <?php $__currentLoopData = $data->images; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $image): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                              <a href="<?php echo e(env('API_URL').$image); ?>" target="_blank" class="image-link"><img src="<?php echo e(env('API_URL').$image); ?>" width="50" height="50"><i class="bi bi-trash-fill text-danger del" onClick="delImage(<?php echo $data->id; ?>,<?php echo $key; ?>,event,this);"></i></a> 
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                          <?php endif; ?>
                        </td>
                        <td><?php echo e(implode(', ', $data->pincode)); ?></td>
                        <td>
                          <a href="<?php echo e(route('admin.add-more-banner',$data->id)); ?>" class="btn btn-primary rounded-pill" >Add More Images</a>
                          <a href="<?php echo e(route('admin.edit-banner',$data->id)); ?>" class="btn btn-warning rounded-pill" >Edit</a>
                          <a href="#" onClick="confirmation(<?php echo $data->id; ?>);" class="btn btn-danger rounded-pill" >Delete</a>
                        </td>
                      </tr>
                      <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                  <?php endif; ?>
                  
                  <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                  <?php $i++; ?>
                  <?php endif; ?>
                </tbody>


              </table>

            </div>
          </div>
        </div>
      </div>
    </section>
  </main>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('script'); ?>
<script src="https://code.jquery.com/jquery-3.7.1.min.js" integrity="sha256-/JqT3SQfawRcv/BIHPThkBvs0OEvtFFmqPF/lYI/Cxo=" crossorigin="anonymous"></script>
<script type="text/javascript">
  function confirmation(value){
     event.preventDefault();
        alertify.confirm("Are you Sure you Want to Delete?", function (e) {
      if (e) {
         window.location.href = "<?php echo e(url('')); ?>/admin/delete-banner/"+value;
       }
      else{
       }
     });
  }

  function delImage(banner_id,value, event,element) {

    event.preventDefault();

    var parentAnchor = $(element).closest('.image-link');

    $.ajax({
        url: '/admin/delete-banner-image/'+banner_id+'/'+value,
        type: 'GET',
        success: function(response) {

            parentAnchor.remove();
        },
        error: function(xhr, status, error) {
            // Handle errors if any
            console.error(error);
        }
    });

  }
</script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('backend.layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH F:\xampp8.2\htdocs\mns\resources\views/backend/banner/view_banners.blade.php ENDPATH**/ ?>