<?php $__env->startSection('main-content'); ?>
<style type="text/css">
  
   <style>
        
        .chat-container {
            max-width: 600px;
            margin: 20px auto;
            border: 1px solid #ccc;
            border-radius: 10px;
            padding: 10px;
        }
        .chat-message {
            display: flex;
            align-items: center;
            margin-bottom: 10px;
        }
        .chat-message.admin {
            justify-content: flex-end;
        }
        .chat-message .message-content {
            max-width: 70%;
            padding: 10px;
            border-radius: 10px;
            background-color: #f1f1f1;
            position: relative;
        }
        .chat-message .message-content::after {
            content: attr(data-time);
            position: relative;
            margin-bottom: -20px;
            margin-right: 0;
            font-size: 0.8em;
            color: #666;
        }

        .chat-message.admin .message-content::after{
           color: #fff;

        }
        .chat-message .message-content::before {
            content: attr(data-date);
            position: absolute;
            top: -20px;
            right: 0;
            font-size: 0.8em;
            color: #666;
        }
        .chat-message.admin .message-content {
            background-color: #007bff;
            color: #fff;
        }
        .chat-footer {
            display: flex;
            align-items: center;
            margin-top: 10px;
        }
        .chat-footer input {
            flex-grow: 1;
            margin-right: 10px;
        }
        .chat-date {
            text-align: center;
            font-size: 0.9em;
            color: #fff;
            margin: 0 auto;
            width: 90px;
            background: #666;
            border-radius: 10px;
            padding: 5px;
        }

    </style>
</style>
  <main id="main" class="main">
    <section class="section">
      <div class="row">
        
      
        <div class="col-lg-12">
          <div class="card">
            <div class="card-body">
              <h5 class="card-title">Chat</h5>              

            </div>
          </div>
         
        </div>
      </div>

        <div class="row">
          <!-- Sidebar with user list -->
          <div class="chat-container">
              
              
               <div class="chat-body" id="chat-body" style="height: 400px; overflow-y: scroll;">
                  <!-- Chat messages will be appended here dynamically -->
              </div>
              <div class="chat-footer">
                  <input type="text" class="form-control" id="chat-input" placeholder="Type a message">
                  <button class="btn btn-primary" id="send-btn">Send</button>
              </div>
          </div>
      </div>
    </section>
  </main>

<?php $__env->stopSection(); ?>


<?php $__env->startSection('script'); ?>

<script>
  const socket = new WebSocket('wss://mindufin.shellcode.cloud');
  const UserId = '<?php echo e($user_id); ?>'; // Set this value in your blade template
  const AdminId = '<?php echo e(session('admin')->id); ?>'; // Set this value in your blade template

  let isSendingMessage = false;

  socket.onopen = function(event) {
      console.log('WebSocket connection established');
      
      const initializeAdmin = {
          type: "initializeAdmin"
      };
      socket.send(JSON.stringify(initializeAdmin));

      const getChatMessage = {
          type: "getChatByUserId",
          userId: UserId
      };
      socket.send(JSON.stringify(getChatMessage));
  };

  socket.onmessage = function(event) {
      const data = JSON.parse(event.data);
      
      if (data.type === 'chatByUserId' && data.userId == UserId) {
          displayChatMessages(data.chat);
      } else if (data.type === 'newMessage' && data.userId == UserId) {
          // Only append message if it's not in the process of sending

          if (!isSendingMessage) {
              appendMessage(data.message);
          }
          isSendingMessage = false; // Reset the flag after appending the message

      }
  };

  document.getElementById('send-btn').addEventListener('click', function() {
      sendMessage();
  });

  document.getElementById('chat-input').addEventListener('keypress', function(event) {
      if (event.key === 'Enter') {
          sendMessage();
      }
  });

  function sendMessage() {
      const input = document.getElementById('chat-input');
      const message = input.value.trim();
      if (message) {
          const sendMessage = {
              type: "sendMessageAdmin",
              userId: UserId,
              message: message
          };

          isSendingMessage = true;
          socket.send(JSON.stringify(sendMessage));
          input.value = '';

      }
  }

  function displayChatMessages(chatData) {
      chatData.sort((a, b) => {
          if (a.date === 'Today') return 1;
          if (b.date === 'Today') return -1;
          return new Date(a.date) - new Date(b.date);
      });

      const chatBody = document.getElementById('chat-body');
      chatBody.innerHTML = ''; // Clear existing messages

      chatData.forEach(chat => {
          appendDate(chat.date);
          chat.chats.forEach(message => {
              appendMessage(message, true); // Mark messages from server
          });
      });

      scrollToBottom();
  }

  function appendDate(date) {
      const chatBody = document.getElementById('chat-body');
      const dateElement = document.createElement('div');
      dateElement.className = 'chat-date';
      dateElement.innerText = date;
      chatBody.appendChild(dateElement);
  }

  function appendMessage(message, fromServer = true) {

     const chatBody = document.getElementById('chat-body');
      const messageElement = document.createElement('div');
      messageElement.className = `chat-message ${message.role}`;
      messageElement.innerHTML = `
          <div class="message-content" data-time="${message.formattedTime}">
              ${message.message}
              <span class="message-date"></span>
          </div>`;
      chatBody.appendChild(messageElement);
      scrollToBottom();
  }

  function scrollToBottom() {
      const chatBody = document.getElementById('chat-body');
      chatBody.scrollTop = chatBody.scrollHeight;
  }
</script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('backend.layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/u511712962/domains/mindufin.site/public_html/resources/views/backend/users/view_chat.blade.php ENDPATH**/ ?>