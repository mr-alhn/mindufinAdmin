<?php $__env->startSection('main-content'); ?>
<style type="text/css">
    .video{
        display: none;
    }
</style>
<main id="main" class="main">
    <div class="pagetitle">
        <h1><?php echo e($title ? $title : "Add new Video"); ?></h1>
    </div>
    <section class="section">
        <div class="row">
            <div class="col-lg-1"></div>
            <div class="col-lg-10">
                <div class="card">
                    <div class="card-body">
                        <h5 class="card-title"> </h5>
                        <form action="<?php echo e(!empty($record) ? url('admin/update-video') : url('admin/add-video')); ?>" method="POST" enctype="multipart/form-data" class="row g-3">

                        <?php echo csrf_field(); ?>
                            <input type="hidden" name="id" value="<?= !empty($record['id']) ? $record['id'] : '' ?>">
                            <div class="col-12">
                                <label for="jobtitle" class="form-label">Title</label>
                                <input type="text" required name="title" class="form-control" id="title" placeholder="Enter Title" value="<?= !empty($record['title']) ? $record['title'] : '' ?>">
                            </div>
                            <br>
                            <div class="col-12">
                                <label for="jobtitle" class="form-label">Video Type</label>
                                
                                <select  required name="videoType" class="form-control" id="type">
                                    <option value="">Select Type</option>
                                    <option value="yt" <?php echo e(!empty($record['videoType']) && $record['videoType'] == 'yt' ? 'selected' : ''); ?>>Youtube</option>
                                    <option value="file" <?php echo e(!empty($record['videoType']) && $record['videoType'] == 'file' ? 'selected' : ''); ?>>Upload File</option>
                                </select>
                            </div>
                            <br>
                            <div class="col-12 video">
                                <label for="jobDescription" class="form-label">Video </label>
                                <input type="file" name="video" class="form-control" id="vidoe" placeholder="" >
                            </div>

                            <div class="col-12 youtube">
                                <label for="jobDescription" class="form-label">Video URL </label>
                                <input type="url" name="url" class="form-control" id="vidoe" placeholder="Enter Video URL" value="<?php echo e(!empty($record['video']) && $record['videoType'] == 'yt' ? $record['video'] : ''); ?>" >
                            </div>

                            <?php if(!empty($record)){ ?>
                                <input type="hidden" name="oldVideo" value="<?php echo e($record['video']); ?>">
                                <input type="hidden" name="oldvideoThumb" value="<?php echo e($record['videoThumb']); ?>">
                            <?php }?>
                            <br>
                            <div class="col-12">
                                <label for="jobDescription" class="form-label">Video Thumbnail </label>
                                <input type="file" name="videoThumb" class="form-control" id="image" placeholder="" >
                            </div>
                            <br>

                            <div class="col-12">
                                <label for="jobtitle" class="form-label">Date</label>
                                <input type="date" required name="date" class="form-control" id="title" placeholder="Enter Date" value="<?= !empty($record['date']) ? date('Y-m-d',strtotime($record['date'])) : '' ?>">
                            </div>
                            <br>
                                <div class="col-12">
                                    <label for="jobtitle" class="form-label">Pincode</label>
                                    <select class="form-select dynamic-tags" required name="pincode[]"  multiple>
                                    <?php if(!empty($record)){ ?>
                                    <?php $__currentLoopData = $record['pincode']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $pincode): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <option value="<?php echo e($pincode); ?>"  selected ><?php echo e($pincode); ?></option>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    <?php } ?>
                                    </select>
                                </div>
                            <br>
                            <div class="col-12">
                                <label for="jobtitle" class="form-label">Select City</label>
                               
                                <select class="form-select dynamic-cities" required name="cityId[]"  multiple>
                                <?php if(!empty($cities)){ ?>
                                <?php $__currentLoopData = $cities; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $city): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <option value="<?php echo e($city->id); ?>" <?php echo e((!empty($record)) && (in_array($city->id,$record['cityId'])) ? 'selected' : ''); ?>><?php echo e($city->name); ?></option>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                <?php } ?>

                                </select>


                            </div>
                            <br>
                            <div class="col-12">
                                <label for="jobtitle" class="form-label">Description</label>
                                <textarea type="text" rows="4" required name="description" class="form-control" id="description" placeholder="Enter description"><?= !empty($record['description']) ? $record['description'] : '' ?>
                                </textarea>
                            </div>
                            <br>
                            <div class="col-12">
                                <label for="source" class="form-label">Source</label>
                                <input type="text" required name="source" class="form-control" id="source" placeholder="Enter Source" value="<?= !empty($record['source']) ? $record['source'] : '' ?>">
                            </div>
                            <br>

                            
                                
                            
                            <div class="text-center"><button type="submit" class="btn btn-primary">Submit</button> </div>
                        </form>
                    </div>
                </div>
            </div>
            <div class="col-lg-1"></div>
        </div>
    </section>
</main>
<?php $__env->stopSection(); ?>


<?php $__env->startSection('script'); ?>


<script type="text/javascript">
    
    $(document).ready(function(){
        
        var initialOption = $('#type').val();
       
        if (initialOption == 'yt') {
            $('.video').hide();
            $('.youtube').show();
        } else {
            $('.video').show();
            $('.youtube').hide();
        }

        $('#type').change(function(){
            var option = $(this).val();

            if(option == 'yt'){

                $('.video').hide();
                $('.youtube').show();
            }
            else{
                $('.video').show();
                $('.youtube').hide();
            }
        })
    });

</script>
<style type="text/css">
    .select2-dropdown.select2-dropdown--below,.select2-dropdown.select2-dropdown--above, .select2-results__option.select2-results__message{
        display: block;
    }
</style>
<script>
    $(document).ready(function() {

    $("select.dynamic-cities").select2({
      tags: true,
      multiple: true,
      placeholder: "Select City",
      createTag: (params) => {
        return {
          id: params.term,
          text: params.term,
        };
      }
    });
  })
</script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('backend.layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH F:\xampp8.2\htdocs\mns\resources\views/backend/video/add_video.blade.php ENDPATH**/ ?>