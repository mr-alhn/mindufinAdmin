<footer id="footer" class="footer">
    <div class="copyright">
      &copy; Copyright <strong><span>Rockstar Studio</span></strong>. All Rights Reserved
    </div>
  </footer><?php /**PATH F:\xampp8.2\htdocs\mns\resources\views/backend/layouts/footer.blade.php ENDPATH**/ ?>