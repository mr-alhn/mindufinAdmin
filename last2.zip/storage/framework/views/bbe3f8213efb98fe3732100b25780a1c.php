<?php $__env->startSection('main-content'); ?>
<main id="main" class="main">
    <div class="pagetitle">
        <h1><?php echo e($title ? $title : "Add new Maharashtra Updates"); ?></h1>
    </div>
    <section class="section">
        <div class="row">
            <div class="col-lg-1"></div>
            <div class="col-lg-10">
                <div class="card">
                    <div class="card-body">
                        <h5 class="card-title"> </h5>
                        <form action="<?php echo e(!empty($record) ? url('admin/update-maharashtra') : url('admin/add-maharashtra-updates')); ?>" method="POST" enctype="multipart/form-data" class="row g-3">

                        <?php echo csrf_field(); ?>
                        <input type="hidden" name="id" value="<?= !empty($record['id']) ? $record['id'] : '' ?>">

                            <div class="col-12">
                                <label for="jobtype" name="type" class="form-label">City</label>
                                <div class="col-sm-12">
                                    <select id="city" name="cityId" class="form-select" required>
                                        <option value="">Choose City</option>
                                        <?php if(!empty($cities)): ?>
                                        <?php $__currentLoopData = $cities; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $city): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <option value="<?php echo e($city->id); ?>" <?php if(!empty($record['cityId']) && $record['cityId'] == $city->id): ?> selected <?php endif ?> ><?php echo e($city->name); ?></option>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                        <?php endif; ?>
                                    </select>
                                </div>
                            </div>
                            <br>
                            <div class="col-12">
                                <label for="jobtitle" class="form-label">Title</label>
                                <input type="text" required name="title" class="form-control" id="title" placeholder="Enter title" value="<?= !empty($record['title']) ? $record['title'] : '' ?>">
                            </div>
                            <br>
                            <div class="col-12">
                                <label for="jobtitle" class="form-label">Description</label>
                                <input type="text" required name="description" class="form-control" id="description" placeholder="Enter description" value="<?= !empty($record['description']) ? $record['description'] : '' ?>">
                            </div>
                            <br>
                            <div class="col-12">
                                <label for="jobtitle" class="form-label">Date</label>
                                <input type="date" required name="date" class="form-control" id="quote" placeholder="Enter Date" value="<?= !empty($record['date']) ? date('Y-m-d', strtotime($record['date'])) : '' ?>">
                            </div>
                            <br>
                            <?php if(empty($record)): ?>
                                <div class="col-12">
                                    <label for="jobDescription" class="form-label">Image</label>
                                    <input type="file" <?php if(empty($record)): ?> required <?php endif; ?> name="image" class="form-control" id="image" placeholder="" >
                                </div>
                                <br>
                            <?php endif; ?>
                            
                            <div class="text-center"><button type="submit" class="btn btn-primary">Submit</button> </div>
                        </form>
                    </div>
                </div>
            </div>
            <div class="col-lg-1"></div>
        </div>
    </section>
</main>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('backend.layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH F:\xampp8.2\htdocs\mns\resources\views/backend/maharashtra-updates/add_maharashtra_updates.blade.php ENDPATH**/ ?>