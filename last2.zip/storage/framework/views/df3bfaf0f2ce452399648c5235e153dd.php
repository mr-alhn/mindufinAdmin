<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="utf-8">
  <meta content="width=device-width, initial-scale=1.0" name="viewport">
  <title>Admin Login - <?php echo e(__('auth.title')); ?></title>
  <meta content="" name="description">
  <meta content="" name="keywords">
  <!-- Favicons -->
  <link href="<?php echo e(asset('backend/assets/img/favicon.png')); ?>" rel="icon">
  <link href="<?php echo e(asset('backend/assets/img/apple-touch-icon.png')); ?>" rel="apple-touch-icon">
  <!-- Google Fonts -->
  <link href="https://fonts.gstatic.com" rel="preconnect">
  <link href="https://fonts.googleapis.com/css?family=Open+Sans:300,300i,400,400i,600,600i,700,700i|Nunito:300,300i,400,400i,600,600i,700,700i|Poppins:300,300i,400,400i,500,500i,600,600i,700,700i" rel="stylesheet">
  <link href="<?php echo e(asset('backend/assets/vendor/bootstrap/css/bootstrap.min.css')); ?>" rel="stylesheet">
  <link href="<?php echo e(asset('backend/assets/vendor/bootstrap-icons/bootstrap-icons.css')); ?>" rel="stylesheet">
  <link href="<?php echo e(asset('backend/assets/vendor/boxicons/css/boxicons.min.css')); ?>" rel="stylesheet">
  <link href="<?php echo e(asset('backend/assets/vendor/quill/quill.snow.css')); ?>" rel="stylesheet">
  <link href="<?php echo e(asset('backend/assets/vendor/quill/quill.bubble.css')); ?>" rel="stylesheet">
  <link href="<?php echo e(asset('backend/assets/vendor/remixicon/remixicon.css')); ?>" rel="stylesheet">
  <link href="<?php echo e(asset('backend/assets/vendor/simple-datatables/style.css')); ?>" rel="stylesheet">
  <link href="<?php echo e(asset('backend/assets/css/style.css')); ?>" rel="stylesheet">
</head>
<body>
  <main>
    <div class="container">
      <section class="section register min-vh-100 d-flex flex-column align-items-center justify-content-center py-4">
        <div class="container">
          <div class="row justify-content-center">
            <div class="col-lg-4 col-md-6 d-flex flex-column align-items-center justify-content-center">
              <div class="d-flex justify-content-center py-4">
                <a href="javascript:void(0)" class="logo d-flex align-items-center w-auto">
                  <!-- <img src="<?php echo e(asset('backend')); ?>/assets/img/logo.png" alt=""> -->
                  <br>
                  <span class="d-none d-lg-block"> <?php echo e(__('auth.title')); ?> Admin Panel</span>
                </a>
              </div><!-- End Logo -->
              <div class="card mb-3">
                <div class="card-body">
                  <?php if(session('success')): ?>
                  <div class="pt-2 alert border-success alert-dismissible fade show" role="alert">
                     <?php echo e(session('success')); ?>

                    <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
                  </div>
                  <?php elseif(session('error')): ?>
                  <div class="pt-2 alert border-danger alert-dismissible fade show" role="alert">
                     <?php echo e(session('error')); ?>

                    <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
                  </div>
                  <?php endif; ?>
                  <div class="pt-4 pb-2">
                    <h5 class="card-title text-center pb-0 fs-4"><?php echo e(__('auth.login')); ?></h5>
                    <p class="text-center small"><?php echo e(__('auth.login_subheading')); ?></p>
                  </div>
                  <form class="row g-3   <?php echo e($errors->any() ? 'was-validated' : ''); ?>"  action="<?php echo e(route('admin.auth')); ?>" method="POST" novalidate>
                    <?php echo csrf_field(); ?>
                    <div class="col-12">
                      <label for="yourPassword" class="form-label"><?php echo e(__('forms.email')); ?></label>
                      <div class="input-group has-validation">
                        <input type="text" name="email" class="form-control" placeholder="<?php echo e(__('forms.enter_email')); ?>" id="yourPassword" required value="<?php echo e(old('email')); ?>">
                        <?php $__errorArgs = ['email'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                            <span class="invalid-feedback error" role="alert">
                                <strong><?php echo e($message); ?></strong>
                            </span>
                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                      </div>
                    </div>
                    <div class="col-12">
                      <label for="yourPassword" class="form-label"><?php echo e(__('forms.password')); ?></label>
                      <input type="password" name="password" class="form-control" placeholder="<?php echo e(__('forms.enter_password')); ?>" id="yourPassword" required>
                      <?php $__errorArgs = ['password'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                          <span class="invalid-feedback" role="alert">
                              <strong><?php echo e($message); ?></strong>
                          </span>
                      <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                    </div>
                    <div class="col-12">
                      <button class="btn btn-primary w-100" type="submit"><?php echo e(__('forms.login_button')); ?></button>
                    </div>
                  </form>
                  <br>
                </div>
              </div>
            </div>
          </div>
        </div>
      </section>
    </div>
  </main>
  <a href="#" class="back-to-top d-flex align-items-center justify-content-center"><i class="bi bi-arrow-up-short"></i></a>
  <script src="<?php echo e(asset('backend/assets/vendor/apexcharts/apexcharts.min.js')); ?>"></script>
  <script src="<?php echo e(asset('backend/assets/vendor/bootstrap/js/bootstrap.bundle.min.js')); ?>"></script>
  <script src="<?php echo e(asset('backend/assets/vendor/chart.js/chart.min.js')); ?>"></script>
  <script src="<?php echo e(asset('backend/assets/vendor/echarts/echarts.min.js')); ?>"></script>
  <script src="<?php echo e(asset('backend/assets/vendor/quill/quill.min.js')); ?>"></script>
  <script src="<?php echo e(asset('backend/assets/vendor/simple-datatables/simple-datatables.js')); ?>"></script>
  <script src="<?php echo e(asset('backend/assets/vendor/tinymce/tinymce.min.js')); ?>"></script>
  <script src="<?php echo e(asset('backend/assets/vendor/php-email-form/validate.js')); ?>"></script>
  <script src="<?php echo e(asset('backend/assets/js/main.js')); ?>"></script>
</body>
</html><?php /**PATH F:\xampp8.2\htdocs\mindufin\resources\views/backend/login.blade.php ENDPATH**/ ?>