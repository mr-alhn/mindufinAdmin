<footer id="footer" class="footer">
    <div class="copyright">
      &copy; <?php echo e(__('dashboard.copyright')); ?> <strong><span><?php echo e(__('auth.title')); ?></span></strong>. <?php echo e(__('dashboard.all_rights')); ?>

    </div>
  </footer><?php /**PATH /home/u511712962/domains/mindufin.site/public_html/resources/views/backend/layouts/footer.blade.php ENDPATH**/ ?>