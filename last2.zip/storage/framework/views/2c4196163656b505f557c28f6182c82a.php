

  <table class="table datatable" id='tbl_exporttable_to_xls'>
    <thead>
      <tr>
        <th scope="col">#</th>
        <th scope="col"><?php echo e(__('tables.user_id')); ?></th>
        <th scope="col"><?php echo e(__('tables.name')); ?></th>
        <th scope="col"><?php echo e(__('tables.email')); ?></th>
        <th scope="col"><?php echo e(__('tables.phone_no')); ?></th>
        <th scope="col"><?php echo e(__('tables.image')); ?></th>
        <th scope="col"><?php echo e(__('tables.created_at')); ?></th>
        <th scope="col"><?php echo e(__('tables.action')); ?></th>

      </tr>
    </thead>
    <tbody>

      <?php if(!empty($records)): ?>
      <?php $i="1"; ?>
      <?php $__currentLoopData = $records; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $row): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
      <tr>
        <th scope="row"><?php echo e($i++); ?></th>
        <td><?php echo e($row->userId); ?></td>
        <td><?php echo e($row->name); ?></td>
        <td><?php echo e($row->email); ?></td>
        <td><?php echo e($row->phone); ?></td>
        <td><img widh="200" height="80" src="<?php echo e(env('API_URL').'/'.$row->avatar); ?>"></td>
        <td><?php echo e(!empty($row->createdAt) ? date('Y-m-d', strtotime($row->createdAt)) : ''); ?></td>
        <td>
          <div class="d-flex align-items-center jsutify-content-center">
            <a href="<?php echo e(url('admin/user/chat/'.$row->id)); ?>" class="btn btn-warning"><?php echo e(__('tables.chat_with_user')); ?></a>
            <a href="<?php echo e(url('admin/user-detail/'.$row->id)); ?>" class="btn btn-primary"><i class="bi bi-pencil"></i></a>
            </div>
        </td>
                          
          
      </tr>
      <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
      <?php $i++; ?>
      <?php endif; ?>
    </tbody>


  </table>

<?php /**PATH /home/u511712962/domains/mindufin.site/public_html/resources/views/backend/users/view_users_data.blade.php ENDPATH**/ ?>