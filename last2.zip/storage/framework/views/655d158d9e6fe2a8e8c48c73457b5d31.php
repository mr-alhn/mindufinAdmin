<?php $__env->startSection('main-content'); ?>
  <main id="main" class="main">
    <section class="section">
      <div class="row">
        
      
        <div class="col-lg-12">
          <div class="card">
            <div class="card-body">
              <h5 class="card-title"><?php echo e(__('sidebar.view_users')); ?></h5>
              
               <div class="row">
                  
                    <div class="col-lg-12">
                      <button class='btn btn-success float-end me-2' onclick="ExportToExcel('xlsx')"><?php echo e(__('tables.export')); ?></button>
                    </div>
                </div>

              <div class="text-center text-bold" ><b id="loader"></b></div>
              
              <div id="users-data"> </div>
              

            </div>
          </div>
         
        </div>
      </div>
    </section>
  </main>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('script'); ?>
<script type="text/javascript" src="https://unpkg.com/xlsx@0.15.1/dist/xlsx.full.min.js"></script>
<script>

  function ExportToExcel(type, fn, dl) {
      var elt = document.getElementById('tbl_exporttable_to_xls');
      var wb = XLSX.utils.table_to_book(elt, { sheet: "sheet1" });
      return dl ?
          XLSX.write(wb, { bookType: type, bookSST: true, type: 'base64' }) :
          XLSX.writeFile(wb, fn || ('Users.' + (type || 'xlsx')));
  }

</script>

<script src="https://code.jquery.com/jquery-3.7.1.min.js" integrity="sha256-/JqT3SQfawRcv/BIHPThkBvs0OEvtFFmqPF/lYI/Cxo=" crossorigin="anonymous"></script>
<script type="">

  const select = (el, all = false) => {
    el = el.trim()
    if (all) {
      return [...document.querySelectorAll(el)]
    } else {
      return document.querySelector(el)
    }
  }

  window.onload = getUsers('all');
  function getUsers(val) 
  {

      $.ajax({
          type: "get",
          url: "<?php echo e(url('admin/get-users')); ?>",
          beforeSend: function() {
              $('#loader').text('Processing...');

          },
          complete: function() {
              $('#loader').text('');

          },
          data: {
              _token: "<?php echo e(csrf_token()); ?>",
              filter:val
          },
          dataType:"JSON",
          success: function(result)
          {
            
            $('#users-data').html(result);

            // Reinitialize datatable
            const datatables = select('.datatable', true)
            datatables.forEach(datatable => {
              new simpleDatatables.DataTable(datatable);
            });
          }
      });
  }

  $('#user-select').change(function(){

    var value = $(this).val();
    getUsers(value);
  });
</script>


<?php $__env->stopSection(); ?>
<?php echo $__env->make('backend.layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH F:\xampp8.2\htdocs\mindufin\resources\views/backend/users/view_users.blade.php ENDPATH**/ ?>