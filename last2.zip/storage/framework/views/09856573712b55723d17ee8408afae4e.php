<aside id="sidebar" class="sidebar">
    <ul class="sidebar-nav" id="sidebar-nav">

      <li class="nav-item">
        <a class="nav-link <?php echo e(Request::is('admin/dashboard') ? '' : 'collapsed'); ?>" href="<?php echo e(url('admin/dashboard')); ?>">
          <i class="bi bi-grid"></i>
          <span><?php echo e(__('sidebar.dashbaord')); ?></span>
        </a>
      </li>
      
      <li class="nav-item">
        <a class="nav-link <?php echo e(Request::is('admin/users') || Request::is('admin/create-user') ? '' : 'collapsed'); ?>" data-bs-target="#users-nav" data-bs-toggle="collapse" href="#">
          <i class="bi bi bi-people"></i><span><?php echo e(__('sidebar.users')); ?></span><i class="bi bi-chevron-down ms-auto"></i>
        </a>
        <ul id="users-nav" class="nav-content  <?php echo e(Request::is('admin/users') || Request::is('admin/create-user') ? '' : 'collapse'); ?>" data-bs-parent="#sidebar-nav">
          <li>
            <a href="<?php echo e(url('admin/create-user')); ?>" class="<?php echo e(Request::is('admin/create-user') ? 'active' : ''); ?>">
              <i class="bi bi-circle"></i><span><?php echo e(__('sidebar.create_user')); ?></span>
            </a>
          </li>
          <li>
            <a href="<?php echo e(url('admin/users')); ?>" class="<?php echo e(Request::is('admin/users') ? 'active' : ''); ?>">
              <i class="bi bi-circle"></i><span><?php echo e(__('sidebar.view_users')); ?></span>
            </a>
          </li>
        </ul>
      </li>


      <li class="nav-item">
        <a class="nav-link <?php echo e(Request::is('admin/reports') || Request::is('admin/bills') ? '' : 'collapsed'); ?>" data-bs-target="#reports-nav" data-bs-toggle="collapse" href="#">
          <i class="bi bi-folder"></i><span><?php echo e(__('sidebar.reports')); ?></span><i class="bi bi-chevron-down ms-auto"></i>
        </a>
        <ul id="reports-nav" class="nav-content  <?php echo e(Request::is('admin/reports') || Request::is('admin/bills') ? '' : 'collapse'); ?>" data-bs-parent="#sidebar-nav">
         
          <li>
            <a href="<?php echo e(url('admin/bills')); ?>" class="<?php echo e(Request::is('admin/bills') ? 'active' : ''); ?>">
              <i class="bi bi-circle"></i><span><?php echo e(__('sidebar.view_bills')); ?></span>
            </a>
          </li>

          <li>
            <a href="<?php echo e(url('admin/reports')); ?>" class="<?php echo e(Request::is('admin/reports') ? 'active' : ''); ?>">
              <i class="bi bi-circle"></i><span><?php echo e(__('sidebar.view_reports')); ?></span>
            </a>
          </li>
        </ul>
      </li>
     

      <li class="nav-item">
        <a class="nav-link <?php echo e(Request::is('admin/send-notification') ? '' : 'collapsed'); ?>" data-bs-target="#noti-nav" data-bs-toggle="collapse" href="#">
          <i class="bi bi-bell-fill"></i><span><?php echo e(__('sidebar.notification')); ?></span><i class="bi bi-chevron-down ms-auto"></i>
        </a>
        <ul id="noti-nav" class="nav-content  <?php echo e(Request::is('admin/send-notification') ? '' : 'collapse'); ?>" data-bs-parent="#sidebar-nav">
          <li>
            <a href="<?php echo e(url('admin/send-notification')); ?>" class="<?php echo e(Request::is('admin/send-notification') ? 'active' : ''); ?>">
              <i class="bi bi-circle"></i><span><?php echo e(__('sidebar.send_notification')); ?></span>
            </a>
          </li>
        </ul>
      </li>
      
      <li class="nav-item">
        <a class="nav-link <?php echo e(Request::is('admin/profile') ? '' : 'collapsed'); ?>" href="<?php echo e(url('admin/profile')); ?>">
          <i class="bi bi-person-fill"></i>
          <span><?php echo e(__('sidebar.profile')); ?></span>
        </a>
      </li>

      
      


      

    </ul>
  </aside><?php /**PATH F:\xampp8.2\htdocs\mindufin\resources\views/backend/layouts/sidebar.blade.php ENDPATH**/ ?>