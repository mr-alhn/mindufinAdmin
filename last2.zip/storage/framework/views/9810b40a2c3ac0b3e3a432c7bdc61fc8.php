<?php $__env->startSection('main-content'); ?>
<style>
    .month-link.disabled {
        pointer-events: none;
        opacity: 0.6;
    }
</style>
<main id="main" class="main">
  <section class="section">
    <div class="row">
      <div class="col-lg-12">
        <div class="card">
          <div class="card-body">
            <h5 class="card-title">View All Bills</h5>
            <div class="row">
              <div class="col-lg-12">
                <select class="form-control" id="yearSelect">
                  <option value="">Select Year</option>
                  <option value="2024">2024</option>
                  <option value="2023">2023</option>
                  <option value="2022">2022</option>
                  <option value="2021">2021</option>
                </select>
              </div>
            </div>             
          </div>
        </div>
      </div>
      <?php
      $months = [
          'January', 'February', 'March', 'April', 'May', 'June',
          'July', 'August', 'September', 'October', 'November', 'December'
      ];
      ?>
      <?php $__currentLoopData = $months; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $index => $month): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
      <div class="col-md-4">
        <a href="#" class="month-link" data-month="<?php echo e($index + 1); ?>" data-month-name="<?php echo e($month); ?>">
          <div class="card">
            <div class="card-header text-center"><i class="bi bi-journals"></i></div>
            <div class="card-body p-0">
              <h5 class="card-title text-center"><?php echo e($month); ?></h5>
            </div>
            <div class="card-footer text-center">
              <i class="bi bi-chevron-right"></i>
            </div>
          </div>
        </a>
      </div>
      <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </div>
  </section>
</main>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('script'); ?>
<script>
$(document).ready(function() {
    var year = null;
    var userId = <?php echo e($userId); ?>;

    $('#yearSelect').change(function() {
        year = $(this).val();
        if (year) {
            $('.month-link').removeClass('disabled');
        } else {
            $('.month-link').addClass('disabled');
        }
    });

    $('.month-link').click(function(e) {
        e.preventDefault();
        if (!year) {
            alertify.error('Please select a year first');
            return;
        }
        var month = $(this).data('month');
        var monthName = $(this).data('month-name');

        var url = '/admin/bill-details?year=' + encodeURIComponent(year) + 
                  '&month=' + encodeURIComponent(monthName) + 
                  '&userId=' + encodeURIComponent(userId);
        
        window.location.href = url;
    });

    // Initially disable all month links
    $('.month-link').addClass('disabled');
});
</script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('backend.layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/u511712962/domains/mindufin.site/public_html/resources/views/backend/bills/view_bills.blade.php ENDPATH**/ ?>