<?php $__env->startSection('main-content'); ?>

<main id="main" class="main">

    <div class="pagetitle">
      <h1>Dashboard</h1>
      <nav>
        <ol class="breadcrumb">
          <li class="breadcrumb-item"><a href="index.html">Home</a></li>
          <li class="breadcrumb-item active">Dashboard</li>
        </ol>
      </nav>
    </div><!-- End Page Title -->


    <section class="section dashboard">
      <div class="row">

        <!-- Left side columns -->
        <div class="col-lg-12">
          <div class="row">

            <!-- Sales Card -->
            <div class="col-xxl-4 col-md-6">
              <div class="card info-card sales-card">
                <div class="card-body">
                  <h5 class="card-title"><?php echo e(__('dashboard.users')); ?></h5>
                  <div class="d-flex align-items-center">
                    <div class="card-icon rounded-circle d-flex align-items-center justify-content-center">
                      <i class="bi bi-person-badge"></i>
                    </div>
                    <div class="ps-3">
                      <h6><?php echo e(!empty($record['totalUsers']) ? $record['totalUsers'] : '0'); ?></h6>
                      <!-- <span class="text-success small pt-1 fw-bold">12%</span> <span class="text-muted small pt-2 ps-1">increase</span> -->
                    </div>
                  </div>
                </div>
              </div>
            </div>
            <!-- End Sales Card -->

            <!-- Revenue Card -->
            <div class="col-xxl-4 col-md-6">
              <div class="card info-card revenue-card">
                <div class="card-body">
                  <h5 class="card-title"><?php echo e(__('dashboard.users_this_month')); ?></h5>
                  <div class="d-flex align-items-center">
                    <div class="card-icon rounded-circle d-flex align-items-center justify-content-center">
                      <i class="bi bi-people"></i>
                    </div>
                    <div class="ps-3">
                      <h6><?php echo e(!empty($record['usersThisMonth']) ? $record['usersThisMonth'] : '0'); ?></h6>
                      <!-- <span class="text-success small pt-1 fw-bold">8%</span> <span class="text-muted small pt-2 ps-1">increase</span> -->
                    </div>
                  </div>
                </div>

              </div>
            </div>
            <!-- End Revenue Card -->
            <!-- Customers Card -->
            <div class="col-xxl-4 col-xl-12">
              <div class="card info-card customers-card">
                <div class="card-body">
                  <h5 class="card-title"><?php echo e(__('dashboard.bills')); ?></h5>
                  <div class="d-flex align-items-center">
                    <div class="card-icon rounded-circle d-flex align-items-center justify-content-center">
                      <i class="bi bi-file-earmark-pdf-fill"></i>
                    </div>
                    <div class="ps-3">
                      <h6><?php echo e(!empty($record['totalBills']) ? $record['totalBills'] : '0'); ?></h6>
                      <!-- <span class="text-danger small pt-1 fw-bold">12%</span> <span class="text-muted small pt-2 ps-1">decrease</span> -->
                    </div>
                  </div>
                </div>
              </div>
            </div>
            <!-- End Customers Card -->
          </div>
        </div><!-- End Left side columns -->
        
        <div class="col-lg-12">
          <div class="row">

             <!-- Customers Card -->
            <div class="col-xxl-4 col-xl-12">
              <div class="card info-card customers-card">
                <div class="card-body">
                  <h5 class="card-title"><?php echo e(__('dashboard.bills_this_year')); ?></h5>
                  <div class="d-flex align-items-center">
                    <div class="card-icon rounded-circle d-flex align-items-center justify-content-center">
                      <i class="bi bi-file-earmark-pdf-fill"></i>
                    </div>
                    <div class="ps-3">
                      <h6><?php echo e(!empty($record['billsThisYear']) ? $record['billsThisYear'] : '0'); ?></h6>
                      <!-- <span class="text-danger small pt-1 fw-bold">12%</span> <span class="text-muted small pt-2 ps-1">decrease</span> -->
                    </div>
                  </div>
                </div>
              </div>
            </div>
            <!-- End Customers Card -->
        

            <!-- Revenue Card -->
            <div class="col-xxl-4 col-md-6">
              <div class="card info-card revenue-card">
                <div class="card-body">
                  <h5 class="card-title"><?php echo e(__('dashboard.bills_this_month')); ?></h5>
                  <div class="d-flex align-items-center">
                    <div class="card-icon rounded-circle d-flex align-items-center justify-content-center">
                      <i class="bi bi-file-earmark-pdf"></i>
                    </div>
                    <div class="ps-3">
                      <h6><?php echo e(!empty($record['billsThisMonth']) ? $record['billsThisMonth'] : '0'); ?></h6>
                      <!-- <span class="text-success small pt-1 fw-bold">8%</span> <span class="text-muted small pt-2 ps-1">increase</span> -->
                    </div>
                  </div>
                </div>

              </div>
            </div>
            <!-- End Revenue Card -->

                <!-- Sales Card -->
            <div class="col-xxl-4 col-md-6">
              <div class="card info-card sales-card">
                <div class="card-body">
                  <h5 class="card-title"><?php echo e(__('dashboard.bills_today')); ?></h5>
                  <div class="d-flex align-items-center">
                    <div class="card-icon rounded-circle d-flex align-items-center justify-content-center">
                      <i class="bi bi-file-earmark-pdf-fill"></i>
                    </div>
                    <div class="ps-3">
                      <h6><?php echo e(!empty($record['billsToday']) ? $record['billsToday'] : '0'); ?></h6>
                      <!-- <span class="text-success small pt-1 fw-bold">12%</span> <span class="text-muted small pt-2 ps-1">increase</span> -->
                    </div>
                  </div>
                </div>
              </div>
            </div>
            <!-- End Sales Card -->
           
          </div>
        </div>
      </div>
    </section>
  </main><!-- End #main -->
<?php $__env->stopSection(); ?>

<?php $__env->startSection('script'); ?>

<!-- <script type="text/javascript">
  
  const socket = new WebSocket('wss://mindufin.shellcode.cloud');

socket.onopen = function(event) {
    console.log('WebSocket connection established');

     const initializeAdmin = {
            type: "initializeAdmin",
         
        };
        socket.send(JSON.stringify(initializeAdmin));
};

socket.onmessage = function(event) {
    console.log('Message received:', event.data);
    // Handle incoming messages here
};

socket.onerror = function(error) {
    console.error('WebSocket error:', error);
};

socket.onclose = function(event) {
    console.log('WebSocket connection closed:', event.code, event.reason);
};
</script> -->
<?php $__env->stopSection(); ?>
<?php echo $__env->make('backend.layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/u511712962/domains/mindufin.site/public_html/resources/views/backend/dashboard.blade.php ENDPATH**/ ?>