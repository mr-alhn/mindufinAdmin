<?php $__env->startSection('main-content'); ?>
  <main id="main" class="main">
    <section class="section">
      <div class="row">
       
        <div class="col-lg-12">
          <div class="card">
            <div class="card-body">
              <h5 class="card-title"><?php echo e($title ? $title : "View All Reels"); ?></h5>
              
              <div class="row">
                  <div class="col-lg-8">
                        <form>
                          <select class="form-control" id="reel-select">
                            <option value="all">All Reels</option>
                            <option value="reels_by_likes">Reels By Like</option>
                            <option value="reels_by_views">Reels By Views</option>
                          </select>
                        </form>
                    </div>

                </div>

              <div class="text-center text-bold" ><b id="loader"></b></div>
              
              <div id="reels-data"> </div>

            </div>
          </div>
        </div>
      </div>
    </section>
  </main>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('script'); ?>
<script src="https://code.jquery.com/jquery-3.7.1.min.js" integrity="sha256-/JqT3SQfawRcv/BIHPThkBvs0OEvtFFmqPF/lYI/Cxo=" crossorigin="anonymous"></script>

<script type="text/javascript">

  const select = (el, all = false) => {
    el = el.trim()
    if (all) {
      return [...document.querySelectorAll(el)]
    } else {
      return document.querySelector(el)
    }
  }

  function confirmation(value){
     event.preventDefault();
        alertify.confirm("Are you Sure you Want to Delete?", function (e) {
      if (e) {
         window.location.href = "<?php echo e(url('')); ?>/admin/delete-reel/"+value;
       }
      else{
       }
     });
  }


  window.onload = getReels('all');
  function getReels(val) 
  {

      $.ajax({
          type: "get",
          url: "<?php echo e(url('admin/get-reels')); ?>",
          beforeSend: function() {
              $('#loader').text('Processing...');

          },
          complete: function() {
              $('#loader').text('');
          },
          data: {
              _token: "<?php echo e(csrf_token()); ?>",
              filter:val
          },
          dataType:"JSON",
          success: function(result)
          {
            
            $('#reels-data').html(result);

            // Reinitialize datatable
            const datatables = select('.datatable', true)
            datatables.forEach(datatable => {
              new simpleDatatables.DataTable(datatable);
            });
          }
      });
  }

  $('#reel-select').change(function(){

    var value = $(this).val();
    getReels(value);
  });


</script>


<?php $__env->stopSection(); ?>
<?php echo $__env->make('backend.layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH F:\xampp8.2\htdocs\mns\resources\views/backend/reel/view_reels.blade.php ENDPATH**/ ?>