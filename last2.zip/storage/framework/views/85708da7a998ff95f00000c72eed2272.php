<?php $__env->startSection('main-content'); ?>
  <main id="main" class="main">
    <section class="section">
      <div class="row">
       
        <div class="col-lg-12">
          <div class="card">
            <div class="card-body">
              <h5 class="card-title"><?php echo e($title ? $title : "View All Maharashtra"); ?></h5>
              <a href="<?php echo e(route('admin.add-updates')); ?>" class="btn btn-success float-right">Add Maharashtra Updates</a>
              <table class="table datatable">
                <thead>
                  <tr>
                    <th scope="col">#</th>
                    <th scope="col">Title</th>
                    <th scope="col">Description</th>
                    <th scope="col">Date</th>
                    <th scope="col">Image</th>
                    <th scope="col">Created At</th>
                    <th scope="col" colspan="2">Action</th>
                  </tr>
                </thead>
                <tbody>
                  <?php if(!empty($records)): ?>
                  <?php $i="1"; ?>
                  <?php $__currentLoopData = $records; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $row): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                  <tr>
                    <th scope="row"><?php echo e($i++); ?></th>
                    <td><?php echo e($row->title); ?></td>
                    <td><?php echo e($row->description); ?></td>
                    <td><?php echo e(date('Y-m-d',strtotime($row->date))); ?></td>
                    <td><img src="<?php echo e($row->image); ?>" width="100" height="100" target="_blank"> </td>
                    <td><?php echo e(!empty($row->createdAt) ? date('Y-m-d', strtotime($row->createdAt)) : ''); ?></td>
                    <td><a href="<?php echo e(route('admin.maharashtra-detail', $row->id)); ?>" class="btn btn-warning rounded-pill" >Edit</a></td>
                    <td><a href="#" onClick="confirmation(<?php echo $row->id; ?>);" class="btn btn-danger rounded-pill" >Delete</a></td>

                  </tr>
                  <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                  <?php $i++; ?>
                  <?php endif; ?>
                </tbody>
              </table>

            </div>
          </div>
        </div>
      </div>
    </section>
  </main>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('script'); ?>
<script type="text/javascript">
  function confirmation(value){
         event.preventDefault();
            alertify.confirm("Are you Sure you Want to Delete?", function (e) {
          if (e) {
             window.location.href = "<?php echo e(url('')); ?>/admin/delete-maharashtra-updates/"+value;
           }
          else{
           }
         });
      }
</script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('backend.layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH F:\xampp8.2\htdocs\mns\resources\views/backend/maharashtra-updates/view_maharashtra_updates.blade.php ENDPATH**/ ?>