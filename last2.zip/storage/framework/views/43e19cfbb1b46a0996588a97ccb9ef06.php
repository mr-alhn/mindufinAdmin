<?php $__env->startSection('main-content'); ?>
  <main id="main" class="main">
    <section class="section">
      <div class="row">
        
      
        <div class="col-lg-12">
          <div class="card">
            <div class="card-body">
              <h5 class="card-title"><?php echo e(__('sidebar.view_reports')); ?></h5>
              
               <div class="row">
                  
                    <div class="col-lg-12">
<!--                       <button class='btn btn-success float-end me-2' onclick="ExportToExcel('xlsx')">Export to excel</button> -->
                      <button class='btn btn-success float-end me-2' id="downloadButton"><?php echo e(__('tables.download_report')); ?>

                    </button>
                    </div>
                </div>

              <div class="text-center text-bold" ><b id="loader"></b></div>
              
              <table class="table datatable" id='tbl_exporttable_to_xls'>
                <thead>
                  <tr>
                    <th scope="col">#</th>
                    <th scope="col"><?php echo e(__('tables.user_id')); ?></th>
                    <th scope="col"><?php echo e(__('tables.name')); ?></th>
                    <th scope="col"><?php echo e(__('tables.email')); ?></th>
                    <th scope="col"><?php echo e(__('tables.phone_no')); ?></th>
                    <th scope="col"><?php echo e(__('tables.attachment')); ?></th>
                    <th scope="col"><?php echo e(__('tables.date')); ?></th>
                    <th scope="col"><?php echo e(__('tables.message')); ?></th>
                    <th scope="col"><?php echo e(__('tables.status')); ?></th>
                    <th scope="col" class="text-center"><?php echo e(__('tables.action')); ?></th>

                  </tr>
                </thead>
                <tbody>

                  <?php if(!empty($records)): ?>
                  <?php $i="1"; ?>
                  <?php $__currentLoopData = $records; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $row): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                  <tr>
                    <th scope="row"><?php echo e($i++); ?></th>
                    <td><?php echo e($row->userId); ?></td>
                    <td><?php echo e($row->name); ?></td>
                    <td><?php echo e($row->email); ?></td>
                    <td><?php echo e($row->number); ?></td>
                    <td>
                      <?php if(!empty($row->attachment)): ?>
                        <?php $i=1; ?>
                        <?php $__currentLoopData = $row->attachment; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $attachment): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                          <a href="<?php echo e(env('API_URL').'/'.$attachment); ?>"><?php echo e(__('tables.attachment')); ?> <?php echo e($i++); ?></a>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                      <?php endif; ?>
                    </td>
                    <td><?php echo e(!empty($row->createdAt) ? date('Y-m-d', strtotime($row->createdAt)) : ''); ?></td>
                    <td>
                      <a href="#" class="d-flex justify-content-center view-message" data-message="<?php echo e($row->message); ?>">
                        <i class="bi bi-eye"></i>
                      </a>
                    </td>
                    <td id="statusCell<?php echo e($row->id); ?>">
                        <?php if($row->status == 'resolved'): ?>
                            <span class="badge bg-success"><?php echo e(__('tables.resolved')); ?></span>
                        <?php elseif($row->status == 'rejected'): ?>
                            <span class="badge bg-danger"><?php echo e(__('tables.rejected')); ?></span>
                        <?php else: ?>
                            <span class="badge bg-warning"><?php echo e(__('tables.pending')); ?></span>
                        <?php endif; ?>
                    </td>
                    <td>
                      <div class="form-check form-switch d-flex justify-content-center align-items-center">
                       
                        <select class="status-toggle" data-id="<?php echo e($row->id); ?>" data-old-value="<?php echo e($row->status); ?>">
<!--                             <option value="pending" <?php echo e($row->status == 'pending' ? 'selected' : ''); ?>>Pending</option> -->
                            <option value="resolved" <?php echo e($row->status == 'resolved' ? 'selected' : ''); ?>><?php echo e(__('tables.resolved')); ?></option>
                            <option value="rejected" <?php echo e($row->status == 'rejected' ? 'selected' : ''); ?>><?php echo e(__('tables.rejected')); ?></option>
                        </select>

                        <a href="#" onClick="confirmation(<?php echo $row->id; ?>);" class="ms-2 btn btn-danger rounded-pill" ><?php echo e(__('tables.delete')); ?></a>
                       
                      </div>
                      
                    </td>
                  </tr>
                  <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                  <?php $i++; ?>
                  <?php endif; ?>
                </tbody>


              </table>
              
            </div>
          </div>
         
        </div>
      </div>
    </section>
  </main>

  <!-- Message Modal -->
<div class="modal fade" id="messageModal" tabindex="-1" aria-labelledby="messageModalLabel" aria-hidden="true">
  <div class="modal-dialog">
    <div class="modal-content">
      <div class="modal-header">
        <h5 class="modal-title" id="messageModalLabel">Full Message</h5>
        <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
      </div>
      <div class="modal-body" id="messageModalBody">
        <!-- Message will be inserted here -->
      </div>
    </div>
  </div>
</div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('script'); ?>

<script src="https://code.jquery.com/jquery-3.7.1.min.js" integrity="sha256-/JqT3SQfawRcv/BIHPThkBvs0OEvtFFmqPF/lYI/Cxo=" crossorigin="anonymous"></script>
<script>

   document.getElementById('downloadButton').addEventListener('click', function () {
            window.location.href = "<?php echo e(route('admin.report.download')); ?>";
        });

</script>


<script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
<script>
    $(document).ready(function () {

      $('.view-message').click(function(e) {
          e.preventDefault();
          var message = $(this).data('message');
          $('#messageModalBody').text(message);
          $('#messageModal').modal('show');
      });

      $('.status-toggle').change(function () {
        const $this = $(this);
        const id = $this.data('id');
        const statusCell = $('#statusCell' + id);
        const status = $this.val();
        const oldValue = $this.data('old-value');

        alertify.confirm("Are you sure you want to update the status?", function (e) {
            if (e) {

                $.ajax({
                    url: '/admin/update-reports-status/' + id,
                    type: 'GET',
                    data: {
                        status: status
                    },
                    success: function (response) {
                        console.log(response);
                        if (status === 'resolved') {
                            statusCell.html('<span class="badge bg-success"><?php echo e(__('tables.resolved')); ?></span>');
                        } else if (status === 'rejected') {
                            statusCell.html('<span class="badge bg-danger"><?php echo e(__('tables.rejected')); ?></span>');
                        } else {
                            statusCell.html('<span class="badge bg-warning"><?php echo e(__('tables.pending')); ?></span>');
                        }
                        alertify.success(response.message);
                        $this.data('old-value', status);
                    },
                    error: function (xhr, status, error) {
                        var data = JSON.parse(xhr.responseText);
                        if (data.hasOwnProperty('errors')) {
                            var errorMessages = data.errors;
                            for (var prop in errorMessages) {
                                if (errorMessages.hasOwnProperty(prop)) {
                                    var messages = errorMessages[prop];
                                    messages.forEach(function (message) {
                                        alertify.error(message);
                                    });
                                }
                            }
                        } else {
                            alertify.error(data.message);
                        }
                        // Revert the select to its previous value
                        $this.val(oldValue);
                    }
                });
            } else {
                // User cancelled, revert the select to its previous value
                $this.val(oldValue);
            }
        });
    });
  });
</script>

<script type="text/javascript">
  function confirmation(value){
     event.preventDefault();
        alertify.confirm("Are you Sure you Want to Delete?", function (e) {
      if (e) {
         window.location.href = "<?php echo e(url('')); ?>/admin/delete-report/"+value;
       }
      else{
       }
     });
  }
</script>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('backend.layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/u511712962/domains/mindufin.site/public_html/resources/views/backend/reports/view_reports.blade.php ENDPATH**/ ?>