<aside id="sidebar" class="sidebar">
    <ul class="sidebar-nav" id="sidebar-nav">
     <!--  <li class="nav-item">
        <a class="nav-link <?php echo e(Request::is('admin/dashboard') ? '' : 'collapsed'); ?>" href="<?php echo e(url('admin/dashboard')); ?>">
          <i class="bi bi-grid"></i>
          <span>Dashboard</span>
        </a>
      </li> -->
      <?php if((!empty(session('role')) && in_array('admin',session('role'))) || (!empty(session('isAdmin')))): ?>

      <li class="nav-item">
        <a class="nav-link <?php echo e(Request::is('admin/sub-admins') || Request::is('admin/add-sub-admin') ? '' : 'collapsed'); ?>" data-bs-target="#admin-nav" data-bs-toggle="collapse" href="#">
          <i class="bi bi-menu-button-wide"></i><span>Admin</span><i class="bi bi-chevron-down ms-auto"></i>
        </a>
        <ul id="admin-nav" class="nav-content  <?php echo e(Request::is('admin/sub-admins') || Request::is('admin/add-sub-admin') ? '' : 'collapse'); ?>" data-bs-parent="#sidebar-nav">
          <li>
            <a href="<?php echo e(url('admin/sub-admins')); ?>" class="<?php echo e(Request::is('admin/sub-admins') ? 'active' : ''); ?>">
              <i class="bi bi-circle"></i><span>View Admin</span>
            </a>
          </li>
          <li>
            <a href="<?php echo e(url('admin/add-sub-admin')); ?>" class="<?php echo e(Request::is('admin/add-sub-admin') ? 'active' : ''); ?>">
              <i class="bi bi-circle"></i><span>Add Admin</span>
            </a>
          </li>
        </ul>
      </li>
      <?php endif; ?>
      <?php if((!empty(session('role')) && in_array('users',session('role'))) || (!empty(session('isAdmin')))): ?>

      <li class="nav-item">
        <a class="nav-link <?php echo e(Request::is('admin/users') ? '' : 'collapsed'); ?>" data-bs-target="#users-nav" data-bs-toggle="collapse" href="#">
          <i class="bi bi-person-fill"></i><span>Users</span><i class="bi bi-chevron-down ms-auto"></i>
        </a>
        <ul id="users-nav" class="nav-content  <?php echo e(Request::is('admin/users') ? '' : 'collapse'); ?>" data-bs-parent="#sidebar-nav">
          <li>
            <a href="<?php echo e(url('admin/users')); ?>" class="<?php echo e(Request::is('admin/users') ? 'active' : ''); ?>">
              <i class="bi bi-circle"></i><span>View Users</span>
            </a>
          </li>
        </ul>
      </li>
      <?php endif; ?>
      <?php if((!empty(session('role')) && in_array('reel',session('role'))) || (!empty(session('isAdmin')))): ?>
      <li class="nav-item">
        <a class="nav-link <?php echo e(Request::is('admin/reels') || Request::is('admin/add-reel') ? '' : 'collapsed'); ?>" data-bs-target="#reels-nav" data-bs-toggle="collapse" href="#">
          <i class="bi bi-camera-fill"></i><span>Reel</span><i class="bi bi-chevron-down ms-auto"></i>
        </a>
        <ul id="reels-nav" class="nav-content  <?php echo e(Request::is('admin/reels') || Request::is('admin/add-reel') ? '' : 'collapse'); ?>" data-bs-parent="#sidebar-nav">
          <li>
            <a href="<?php echo e(url('admin/reels')); ?>" class="<?php echo e(Request::is('admin/reels') ? 'active' : ''); ?>">
              <i class="bi bi-circle"></i><span>View reels</span>
            </a>
          </li>
          <li>
            <a href="<?php echo e(url('admin/add-reel')); ?>" class="<?php echo e(Request::is('admin/add-reel') ? 'active' : ''); ?>">
              <i class="bi bi-circle"></i><span>Add Reel</span>
            </a>
          </li>
        </ul>
      </li>

      <?php endif; ?>
      <?php if((!empty(session('role')) && in_array('news',session('role'))) || (!empty(session('isAdmin')))): ?>
      <li class="nav-item">
        <a class="nav-link <?php echo e(Request::is('admin/news') || Request::is('admin/add-news') ? '' : 'collapsed'); ?>" data-bs-target="#news-nav" data-bs-toggle="collapse" href="#">
          <i class="bi bi-newspaper"></i><span>News</span><i class="bi bi-chevron-down ms-auto"></i>
        </a>
        <ul id="news-nav" class="nav-content  <?php echo e(Request::is('admin/news') || Request::is('admin/add-news') ? '' : 'collapse'); ?>" data-bs-parent="#sidebar-nav">
          <li>
            <a href="<?php echo e(url('admin/news')); ?>" class="<?php echo e(Request::is('admin/news') ? 'active' : ''); ?>">
              <i class="bi bi-circle"></i><span>View News</span>
            </a>
          </li>
          <li>
            <a href="<?php echo e(url('admin/add-news')); ?>" class="<?php echo e(Request::is('admin/add-news') ? 'active' : ''); ?>">
              <i class="bi bi-circle"></i><span>Add News</span>
            </a>
          </li>
        </ul>
      </li>
      <?php endif; ?>
      <?php if((!empty(session('role')) && in_array('video',session('role'))) || (!empty(session('isAdmin')))): ?>
      <li class="nav-item">
        <a class="nav-link <?php echo e(Request::is('admin/videos') || Request::is('admin/add-video') ? '' : 'collapsed'); ?>" data-bs-target="#videos-nav" data-bs-toggle="collapse" href="#">
          <i class="bi bi-camera-video-fill"></i><span>Video</span><i class="bi bi-chevron-down ms-auto"></i>
        </a>
        <ul id="videos-nav" class="nav-content  <?php echo e(Request::is('admin/videos') || Request::is('admin/add-video') ? '' : 'collapse'); ?>" data-bs-parent="#sidebar-nav">
          <li>
            <a href="<?php echo e(url('admin/videos')); ?>" class="<?php echo e(Request::is('admin/videos') ? 'active' : ''); ?>">
              <i class="bi bi-circle"></i><span>View Videos</span>
            </a>
          </li>
          <li>
            <a href="<?php echo e(url('admin/add-video')); ?>" class="<?php echo e(Request::is('admin/add-video') ? 'active' : ''); ?>">
              <i class="bi bi-circle"></i><span>Add Video</span>
            </a>
          </li>
        </ul>
      </li>
      <?php endif; ?>
      <?php if((!empty(session('role')) && in_array('gallery',session('role'))) || (!empty(session('isAdmin')))): ?>
      <li class="nav-item">
        <a class="nav-link <?php echo e(Request::is('admin/gallery-categories') || Request::is('admin/add-gallery-category') ? '' : 'collapsed'); ?>" data-bs-target="#category-nav" data-bs-toggle="collapse" href="#">
          <i class="bi bi-card-image"></i><span>Gallery</span><i class="bi bi-chevron-down ms-auto"></i>
        </a>
        <ul id="category-nav" class="nav-content  <?php echo e(Request::is('admin/gallery-categories') || Request::is('admin/add-gallery-category') ? '' : 'collapse'); ?>" data-bs-parent="#sidebar-nav">
          <li>
            <a href="<?php echo e(url('admin/gallery-categories')); ?>" class="<?php echo e(Request::is('admin/gallery-categories') ? 'active' : ''); ?>">
              <i class="bi bi-circle"></i><span>View Categories</span>
            </a>
          </li>
          <li>
            <a href="<?php echo e(url('admin/add-gallery-category')); ?>" class="<?php echo e(Request::is('admin/add-category') ? 'active' : ''); ?>">
              <i class="bi bi-circle"></i><span>Add Category</span>
            </a>
          </li>
        </ul>
      </li>
      <?php endif; ?>
      <?php if((!empty(session('role')) && in_array('leader-updates',session('role'))) || (!empty(session('isAdmin')))): ?>
      <li class="nav-item">
        <a class="nav-link <?php echo e(Request::is('admin/leader-updates') || Request::is('admin/add-leader-updates') ? '' : 'collapsed'); ?>" data-bs-target="#leader-updates-nav" data-bs-toggle="collapse" href="#">
          <i class="bi bi-person-check"></i><span>Leader Updates</span><i class="bi bi-chevron-down ms-auto"></i>
        </a>
        <ul id="leader-updates-nav" class="nav-content  <?php echo e(Request::is('admin/leader-updates') || Request::is('admin/add-leader-updates') ? '' : 'collapse'); ?>" data-bs-parent="#sidebar-nav">
          <li>
            <a href="<?php echo e(url('admin/leader-updates')); ?>" class="<?php echo e(Request::is('admin/leader-updates') ? 'active' : ''); ?>">
              <i class="bi bi-circle"></i><span>View Leader Updates</span>
            </a>
          </li>
          <li>
            <a href="<?php echo e(url('admin/add-leader-updates')); ?>" class="<?php echo e(Request::is('admin/add-leader-updates') ? 'active' : ''); ?>">
              <i class="bi bi-circle"></i><span>Add Leader Updates</span>
            </a>
          </li>
        </ul>
      </li>
      <?php endif; ?>
      <?php if((!empty(session('role')) && in_array('job-updates',session('role'))) || (!empty(session('isAdmin')))): ?>
      <li class="nav-item">
        <a class="nav-link <?php echo e(Request::is('admin/job-updates') || Request::is('admin/add-job-updates') ? '' : 'collapsed'); ?>" data-bs-target="#job-updates-nav" data-bs-toggle="collapse" href="#">
          <i class="bi bi-funnel-fill"></i><span>Job Updates</span><i class="bi bi-chevron-down ms-auto"></i>
        </a>
        <ul id="job-updates-nav" class="nav-content  <?php echo e(Request::is('admin/job-updates') || Request::is('admin/add-job-updates')  ? '' : 'collapse'); ?>" data-bs-parent="#sidebar-nav">
          <li>
            <a href="<?php echo e(url('admin/job-updates')); ?>" class="<?php echo e(Request::is('admin/job-updates') ? 'active' : ''); ?>">
              <i class="bi bi-circle"></i><span>View Job Updates</span>
            </a>
          </li>
          <li>
            <a href="<?php echo e(url('admin/add-job-updates')); ?>" class="<?php echo e(Request::is('admin/add-job-updates') ? 'active' : ''); ?>">
              <i class="bi bi-circle"></i><span>Add Job Updates</span>
            </a>
          </li>
        </ul>
      </li>  
      <?php endif; ?>
      <?php if((!empty(session('role')) && in_array('complaints',session('role'))) || (!empty(session('isAdmin')))): ?>
      <li class="nav-item">
        <a class="nav-link <?php echo e(Request::is('admin/complaints') ? '' : 'collapsed'); ?>" data-bs-target="#complaints-nav" data-bs-toggle="collapse" href="#">
          <i class="bi bi-person-lines-fill"></i><span>Complaints</span><i class="bi bi-chevron-down ms-auto"></i>
        </a>
        <ul id="complaints-nav" class="nav-content  <?php echo e(Request::is('admin/complaints') ? '' : 'collapse'); ?>" data-bs-parent="#sidebar-nav">
          <li>
            <a href="<?php echo e(url('admin/complaints')); ?>" class="<?php echo e(Request::is('admin/complaints') ? 'active' : ''); ?>">
              <i class="bi bi-circle"></i><span>View Complaints</span>
            </a>
          </li>
        </ul>
      </li>
      <?php endif; ?>
      <?php if((!empty(session('role')) && in_array('city',session('role'))) || (!empty(session('isAdmin')))): ?>
      <li class="nav-item">
        <a class="nav-link <?php echo e(Request::is('admin/cities') || Request::is('admin/add-city') ? '' : 'collapsed'); ?>" data-bs-target="#city-updates-nav" data-bs-toggle="collapse" href="#">
          <i class="bi bi-menu-button-wide"></i><span>City</span><i class="bi bi-chevron-down ms-auto"></i>
        </a>
        <ul id="city-updates-nav" class="nav-content  <?php echo e(Request::is('admin/cities') || Request::is('admin/add-city') ? '' : 'collapse'); ?>" data-bs-parent="#sidebar-nav">
          <li>
            <a href="<?php echo e(url('admin/cities')); ?>" class="<?php echo e(Request::is('admin/cities') ? 'active' : ''); ?>">
              <i class="bi bi-circle"></i><span>View Cities</span>
            </a>
          </li>
          <li>
            <a href="<?php echo e(url('admin/add-city')); ?>" class="<?php echo e(Request::is('admin/add-city') ? 'active' : ''); ?>">
              <i class="bi bi-circle"></i><span>Add City</span>
            </a>
          </li>
        </ul>
      </li>
      <?php endif; ?>
      <?php if((!empty(session('role')) && in_array('notification',session('role'))) || (!empty(session('isAdmin')))): ?>
      <li class="nav-item">
        <a class="nav-link <?php echo e(Request::is('admin/send-notification') ? '' : 'collapsed'); ?>" data-bs-target="#noti-nav" data-bs-toggle="collapse" href="#">
          <i class="bi bi-bell-fill"></i><span>Notification</span><i class="bi bi-chevron-down ms-auto"></i>
        </a>
        <ul id="noti-nav" class="nav-content  <?php echo e(Request::is('admin/send-notification') ? '' : 'collapse'); ?>" data-bs-parent="#sidebar-nav">
          <li>
            <a href="<?php echo e(url('admin/send-notification')); ?>" class="<?php echo e(Request::is('admin/send-notification') ? 'active' : ''); ?>">
              <i class="bi bi-circle"></i><span>Send Notification</span>
            </a>
          </li>
        </ul>
      </li>
      <?php endif; ?>
      <?php if((!empty(session('role')) && in_array('banner',session('role'))) || (!empty(session('isAdmin')))): ?>
      <li class="nav-item">
        <a class="nav-link <?php echo e(Request::is('admin/banners') || Request::is('admin/add-banner') ? '' : 'collapsed'); ?>" data-bs-target="#banners-nav" data-bs-toggle="collapse" href="#">
          <i class="bi bi-menu-button-wide"></i><span>Banner</span><i class="bi bi-chevron-down ms-auto"></i>
        </a>
        <ul id="banners-nav" class="nav-content  <?php echo e(Request::is('admin/banners') || Request::is('admin/add-banner') ? '' : 'collapse'); ?>" data-bs-parent="#sidebar-nav">
          <li>
            <a href="<?php echo e(url('admin/banners')); ?>" class="<?php echo e(Request::is('admin/banners') ? 'active' : ''); ?>">
              <i class="bi bi-circle"></i><span>View Banners</span>
            </a>
          </li>
          <li>
            <a href="<?php echo e(url('admin/add-banner')); ?>" class="<?php echo e(Request::is('admin/add-banner') ? 'active' : ''); ?>">
              <i class="bi bi-circle"></i><span>Add Banner</span>
            </a>
          </li>
        </ul>
      </li>
      <?php endif; ?>
      <?php if((!empty(session('role')) && in_array('popup',session('role'))) || (!empty(session('isAdmin')))): ?>
      <li class="nav-item">
        <a class="nav-link <?php echo e(Request::is('admin/popup') || Request::is('admin/add-popup') ? '' : 'collapsed'); ?>" data-bs-target="#popup-nav" data-bs-toggle="collapse" href="#">
          <i class="bi bi-menu-button-wide"></i><span>Popup</span><i class="bi bi-chevron-down ms-auto"></i>
        </a>
        <ul id="popup-nav" class="nav-content  <?php echo e(Request::is('admin/popup') || Request::is('admin/add-popup') ? '' : 'collapse'); ?>" data-bs-parent="#sidebar-nav">
          <li>
            <a href="<?php echo e(url('admin/popup')); ?>" class="<?php echo e(Request::is('admin/popup') ? 'active' : ''); ?>">
              <i class="bi bi-circle"></i><span>View Popup</span>
            </a>
          </li>
          <li>
            <a href="<?php echo e(url('admin/add-popup')); ?>" class="<?php echo e(Request::is('admin/add-popup') ? 'active' : ''); ?>">
              <i class="bi bi-circle"></i><span>Add Popup</span>
            </a>
          </li>
        </ul>
      </li>
      <?php endif; ?>

      
      


      

    </ul>
  </aside><?php /**PATH F:\xampp8.2\htdocs\mns\resources\views/backend/layouts/sidebar.blade.php ENDPATH**/ ?>