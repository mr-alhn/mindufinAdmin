<?php $__env->startSection('main-content'); ?>
<style type="text/css">
    .video{
        display: none;
    }
</style>
<main id="main" class="main">
    <div class="pagetitle">
        <h1><?php echo e($title ? $title : "Add new Sub Admin"); ?></h1>
    </div>
    <section class="section">
        <div class="row">
            <div class="col-lg-1"></div>
            <div class="col-lg-10">
                <div class="card">
                    <div class="card-body">
                        <h5 class="card-title"> </h5>
                        <form action="<?php echo e(!empty($record) ? url('admin/update-sub-admin') : url('admin/add-sub-admin')); ?>" method="POST" enctype="multipart/form-data" class="row g-3">

                        <?php echo csrf_field(); ?>
                            <input type="hidden" name="id" value="<?= !empty($record['id']) ? $record['id'] : '' ?>">
                            <div class="col-12">
                                <label for="jobtitle" class="form-label">Name</label>
                                <input type="text" required name="name" class="form-control" id="title" placeholder="Enter Name" value="<?= !empty($record['name']) ? $record['name'] : '' ?>">
                            </div>
                            <br>
                            <div class="col-12">
                                <label for="jobtitle" class="form-label">Phone</label>
                                <input type="text" required name="phone" class="form-control" id="title" placeholder="Enter Phone" value="<?= !empty($record['phone']) ? $record['phone'] : '' ?>">
                            </div>
                            <br>
                            <div class="col-12">
                                <label for="jobtitle" class="form-label">Password</label>
                                <input type="text" required name="password" class="form-control" id="title" placeholder="Enter Password" value="<?= !empty($record['password']) ? $record['password'] : '' ?>">
                            </div>
                            <br>
                            <div class="col-12">
                                <label for="jobtitle" class="form-label">Role</label>
                               
                                <select class="form-select dynamic-roles" required name="role[]"  multiple>
                                <?php if(!empty($roles)){ ?>
                                <?php $__currentLoopData = $roles; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $role): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <option value="<?php echo e($role); ?>" selected  ><?php echo e(ucwords($role)); ?></option>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                <?php } ?>

                                </select>
                            </div>
                            <br>
                            <div class="text-center"><button type="submit" class="btn btn-primary">Submit</button> </div>
                        </form>
                    </div>
                </div>
            </div>
            <div class="col-lg-1"></div>
        </div>
    </section>
</main>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('script'); ?>
<style type="text/css">
    .select2-dropdown.select2-dropdown--below,.select2-dropdown.select2-dropdown--above, .select2-results__option.select2-results__message{
        display: block;
    }
</style>
<script>
    $(document).ready(function() {

    $("select.dynamic-roles").select2({
      tags: true,
      multiple: true,
      placeholder: "Enter Role",
      createTag: (params) => {
        return {
          id: params.term,
          text: params.term,
        };
      }
    });
  })
</script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('backend.layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH F:\xampp8.2\htdocs\mindufin\resources\views/backend/sub_admin/add_sub_admin.blade.php ENDPATH**/ ?>