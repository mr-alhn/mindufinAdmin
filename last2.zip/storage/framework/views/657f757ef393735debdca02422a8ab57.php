<?php $__env->startSection('main-content'); ?>
<main id="main" class="main">
    <div class="pagetitle">
        <h1><?php echo e($title ? $title : "Add new Banner"); ?></h1>
    </div>
    <section class="section">
        <div class="row">
            <div class="col-lg-1"></div>
            <div class="col-lg-10">
                <div class="card">
                    <div class="card-body">
                        <h5 class="card-title"> </h5>
                        <form action="<?php echo e(!empty($record) ? url('admin/update-city') : url('admin/add-city')); ?>" method="POST" enctype="multipart/form-data" class="row g-3">

                        <?php echo csrf_field(); ?>
                            <input type="hidden" name="id" value="<?= !empty($record['id']) ? $record['id'] : '' ?>">
                            <div class="col-12">
                                <label for="name" class="form-label">Name</label>
                                <input type="text" required name="name" class="form-control" id="name" placeholder="Enter city Name" value="<?= !empty($record['name']) ? $record['name'] : '' ?>">
                            </div>
                            
                            <br>
                            <?php if(empty($record)){ ?>
                            <div class="col-12">
                                <label for="image" class="form-label">Image</label>
                                <input type="file" required name="image" class="form-control" id="image" multiple="multiple" placeholder="" >
                            </div>
                            <?php } ?>
                            
                            <div class="text-center"><button type="submit" class="btn btn-primary">Submit</button> </div>
                        </form>
                    </div>
                </div>
            </div>
            <div class="col-lg-1"></div>
        </div>
    </section>
</main>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('backend.layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH F:\xampp8.2\htdocs\mns\resources\views/backend/city/add_city.blade.php ENDPATH**/ ?>