

  <table class="table datatable">
      <thead>
        <tr>
          <th scope="col">#</th>
          <th scope="col">Title</th>
          <th scope="col">Pincode</th>
          <th scope="col">Caption</th>
          <th scope="col">View Count</th>
          <th scope="col">Liked Count</th>
          <th scope="col">Video</th>
          <th scope="col" colspan="2">Action</th>
        </tr>
      </thead>
      <tbody>
        <?php if(!empty($records)): ?>
        <?php $i="1"; ?>
        <?php $__currentLoopData = $records; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $row): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <tr>
          <th scope="row"><?php echo e($i++); ?></th>
          <td><?php echo e($row->title); ?></td>
          <td><?php echo e(implode(', ', $row->pincode)); ?></td>
          <td><?php echo e($row->caption); ?></td>
          <td><?php echo e($row->viewCount); ?></td>
          <td><?php echo e($row->likeCount); ?></td>
          <td>
            <a href="<?php echo e(env('API_URL').$row->video); ?>" onclick="window.open(this.href,'_blank');return false;">
                <video width="100" height="80" controls>
                    <source src="<?php echo e(env('API_URL').$row->video); ?>" type="video/mp4">
                    Your browser does not support the video tag.
                </video>
            </a>
        </td>
          <td><a href="<?php echo e(route('admin.reel-detail', $row->id)); ?>"class="btn btn-primary rounded-pill" >Edit</a>
              <a href="#" onClick="confirmation(<?php echo $row->id; ?>);" class="btn btn-danger rounded-pill" >Delete</a>
          </td>
        </tr>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        <?php $i++; ?>
        <?php endif; ?>
      </tbody>


    </table>
<?php /**PATH F:\xampp8.2\htdocs\mns\resources\views/backend/reel/view_reels_data.blade.php ENDPATH**/ ?>