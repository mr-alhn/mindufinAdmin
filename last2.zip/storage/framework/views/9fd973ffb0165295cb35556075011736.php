<?php $__env->startSection('main-content'); ?>
  <main id="main" class="main">
    <section class="section">
      <div class="row">
        
        <div class="col-lg-12">
          <div class="card">
            <div class="card-body">
              <h5 class="card-title"><?php echo e($title ? $title : "View All "); ?></h5>
              <table class="table datatable">
                <thead>
                  <tr>
                    <th scope="col">#</th>
                    <th scope="col">Title</th>
                    <th scope="col">Pincode</th>
                    <th scope="col">Location</th>
                    <th scope="col">Company Name</th>
                    <th scope="col">Duration</th>
                    <th scope="col">Post</th>
                    <th scope="col">Last Date</th>
                    <th scope="col">About Company</th>
                    <th scope="col">About Job </th>
                    <th scope="col">Salary </th>
                    
                    <th scope="col">Action</th>
                  </tr>
                </thead>
                <tbody>
                  <?php if(!empty($records)): ?>
                  <?php $i="1"; ?>
                  <?php $__currentLoopData = $records; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $row): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                  <tr>
                    <th scope="row"><?php echo e($i++); ?></th>
                    <td><?php echo e($row->title); ?></td>
                    <td><?php echo e(implode(', ', $row->pincode)); ?></td>
                    <td><?php echo e($row->location); ?></td>
                    <td><?php echo e($row->companyName); ?></td>
                    <td><?php echo e($row->duration); ?></td>
                    <td><?php echo e($row->requiredPost); ?></td>
                    <td><?php echo e($row->lastDate); ?></td>
                    <td><?php echo e($row->aboutCompany); ?></td>
                    <td><?php echo e($row->aboutJob); ?></td>
                    <td><?php echo e($row->salary); ?></td>
                    
                    <td>
                      <div class="d-flex justify-center align-items-center w-100 h-100">
                        
                        <a href="<?php echo e(route('admin.job-requests', $row->id)); ?>" class="btn btn-primary rounded-pill" >Requests</a>
                        <a href="<?php echo e(route('admin.job-detail', $row->id)); ?>" class="btn btn-warning rounded-pill" >Edit</a>
                        <a href="#" onClick="confirmation(<?php echo $row->id; ?>);" class="btn btn-danger rounded-pill" >Delete</a>  
                      </div>
                      
                    </td>

                  </tr>
                  <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                  <?php $i++; ?>
                  <?php endif; ?>
                </tbody>
              </table>

            </div>
          </div>
        </div>
      </div>
    </section>
  </main>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('script'); ?>
<script type="text/javascript">
  function confirmation(value){
         event.preventDefault();
            alertify.confirm("Are you Sure you Want to Delete?", function (e) {
          if (e) {
             window.location.href = "<?php echo e(url('')); ?>/admin/delete-job-updates/"+value;
           }
          else{
           }
         });
      }
</script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('backend.layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH F:\xampp8.2\htdocs\mns\resources\views/backend/job_updates/view_job_updates.blade.php ENDPATH**/ ?>