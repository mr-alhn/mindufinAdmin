<footer id="footer" class="footer">
    <div class="copyright">
      &copy; <?php echo e(__('dashboard.copyright')); ?> <strong><span><?php echo e(__('auth.title')); ?></span></strong>. <?php echo e(__('dashboard.all_rights')); ?>

    </div>
  </footer><?php /**PATH F:\xampp8.2\htdocs\mindufin\resources\views/backend/layouts/footer.blade.php ENDPATH**/ ?>