<?php $__env->startSection('main-content'); ?>
<main id="main" class="main">
    <div class="pagetitle">
        <h1><?php echo e($title ? $title : "Add new Banner"); ?></h1>
    </div>
    <section class="section">
        <div class="row">
            <div class="col-lg-1"></div>
            <div class="col-lg-10">
                <div class="card">
                    <div class="card-body">
                        <h5 class="card-title"> </h5>
                        <form action="<?php echo e(url('admin/add-more-banner')); ?>" method="POST" enctype="multipart/form-data" class="row g-3">

                        <?php echo csrf_field(); ?>
                            <input type="hidden" name="id" value="<?= !empty($id) ? $id : '' ?>">
                            <!-- <input type="hidden" name="page" value="News"> -->

                            <div class="col-12">
                                <label for="jobtitle" class="form-label">Select Page</label>
                                
                                <select  required name="page" class="form-control" id="page">
                                    <option value="">Select Page</option>
                                    <option value="News">News</option>
                                    <option value="Video">Video</option>
                                    <option value="Gallery">Gallery</option>
                                    <option value="Complaints">Complaints</option>
                                    <option value="Leader">Leader</option>
                                    <option value="Maharashtra">Maharashtra</option>
                                    <option value="Job">Job</option>
                                </select>
                            </div>
                            <br>
                            
                            <div class="col-12">
                                <label for="jobDescription" class="form-label">Banner Image</label>
                                <input type="file" required name="images" class="form-control" id="image" placeholder="" >
                            </div>
                            <br>
                            
                            <div class="text-center"><button type="submit" class="btn btn-primary">Submit</button> </div>
                        </form>
                    </div>
                </div>
            </div>
            <div class="col-lg-1"></div>
        </div>
    </section>
</main>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('backend.layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH F:\xampp8.2\htdocs\mns\resources\views/backend/banner/add_more_banner.blade.php ENDPATH**/ ?>