<?php $__env->startSection('main-content'); ?>
<main id="main" class="main">
    <div class="pagetitle">
        <h1><?php echo e($title ? $title : "Add new Gallery"); ?></h1>
    </div>
    <section class="section">
        <div class="row">
            <div class="col-lg-1"></div>
            <div class="col-lg-10">
                <div class="card">
                    <div class="card-body">
                        <h5 class="card-title"> </h5>
                        <form action="<?php echo e(!empty($record) ? url('admin/update-popup') : url('admin/add-popup')); ?>" method="POST" enctype="multipart/form-data" class="row g-3">

                        <?php echo csrf_field(); ?>
                            <input type="hidden" name="id" value="<?= !empty($record['id']) ? $record['id'] : '' ?>">
                            
                            <br>
                            <?php if(empty($record)){ ?>
                                <div class="col-12">
                                    <label for="jobDescription" class="form-label"> Image</label>
                                    <input type="file" required name="image" class="form-control" id="image" placeholder="" >
                                </div>
                                <br>
                            <?php } ?>

                            <div class="col-12">
                                <label for="jobtitle" class="form-label">Pincode</label>
                                
                                <select class="form-select dynamic-tags" required name="pincode[]"  multiple>
                                <?php if(!empty($record)){ ?>
                                <?php $__currentLoopData = $record['pincode']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $pincode): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <option value="<?php echo e($pincode); ?>"  selected ><?php echo e($pincode); ?></option>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                <?php } ?>
                                </select>

                            </div>
                            
                            <div class="text-center"><button type="submit" class="btn btn-primary">Submit</button> </div>
                        </form>
                    </div>
                </div>
            </div>
            <div class="col-lg-1"></div>
        </div>
    </section>
</main>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('backend.layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH F:\xampp8.2\htdocs\mns\resources\views/backend/popup/add_popup.blade.php ENDPATH**/ ?>