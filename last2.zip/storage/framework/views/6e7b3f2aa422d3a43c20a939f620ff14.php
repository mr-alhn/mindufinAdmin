<?php $__env->startSection('main-content'); ?>
  <main id="main" class="main">
    <section class="section">
      <div class="row">
        
      
        <div class="col-lg-12">
          <div class="card">
            <div class="card-body">
              <h5 class="card-title"><?php echo e(__('sidebar.view_users')); ?></h5>
              
               <div class="row">
                  
                    <!-- <div class="col-lg-12">
                      <button class='btn btn-success float-end me-2' onclick="ExportToExcel('xlsx')"><?php echo e(__('tables.export')); ?></button>
                    </div> -->
                </div>

              <div class="text-center text-bold" ><b id="loader"></b></div>
              
              <table class="table datatable" id='tbl_exporttable_to_xls'>
                <thead>
                  <tr>
                    <th scope="col">#</th>
                    <th scope="col"><?php echo e(__('tables.user_id')); ?></th>
                    <th scope="col"><?php echo e(__('tables.name')); ?></th>
                    <th scope="col"><?php echo e(__('tables.email')); ?></th>
                    <th scope="col"><?php echo e(__('tables.phone_no')); ?></th>
                    <th scope="col"><?php echo e(__('tables.image')); ?></th>
                    <th scope="col"><?php echo e(__('tables.created_at')); ?></th>
                    <!-- <th scope="col"><?php echo e(__('tables.action')); ?></th> -->

                  </tr>
                </thead>
                <tbody>

                  <?php if(!empty($records)): ?>
                  <?php $i="1"; ?>
                  <?php $__currentLoopData = $records; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $row): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                  <tr>
                    <th scope="row"><?php echo e($i++); ?></th>
                    <td><a href="<?php echo e(url('admin/bills/'.$row->userId)); ?>"><?php echo e($row->userId); ?></a></td>
                    <td><?php echo e($row->name); ?></td>
                    <td><?php echo e($row->email); ?></td>
                    <td><?php echo e($row->phone); ?></td>
                    <td><img widh="200" height="80" src="<?php echo e(env('API_URL').'/'.$row->avatar); ?>"></td>
                    <td><?php echo e(!empty($row->createdAt) ? date('Y-m-d', strtotime($row->createdAt)) : ''); ?></td>
                    <!-- <td>
                      <div class="d-flex align-items-center jsutify-content-center">
                        <a href="<?php echo e(url('admin/user/chat/'.$row->id)); ?>" class="btn btn-warning"><?php echo e(__('tables.chat_with_user')); ?></a>
                        <a href="<?php echo e(url('admin/user-detail/'.$row->id)); ?>" class="btn btn-primary"><i class="bi bi-pencil"></i></a>
                        </div>
                    </td> -->
                                      
                      
                  </tr>
                  <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                  <?php $i++; ?>
                  <?php endif; ?>
                </tbody>


              </table>
              

            </div>
          </div>
         
        </div>
      </div>
    </section>
  </main>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('script'); ?>
<script type="text/javascript" src="https://unpkg.com/xlsx@0.15.1/dist/xlsx.full.min.js"></script>
<script>

  function ExportToExcel(type, fn, dl) {
      var elt = document.getElementById('tbl_exporttable_to_xls');
      var wb = XLSX.utils.table_to_book(elt, { sheet: "sheet1" });
      return dl ?
          XLSX.write(wb, { bookType: type, bookSST: true, type: 'base64' }) :
          XLSX.writeFile(wb, fn || ('Users.' + (type || 'xlsx')));
  }

</script>

<script src="https://code.jquery.com/jquery-3.7.1.min.js" integrity="sha256-/JqT3SQfawRcv/BIHPThkBvs0OEvtFFmqPF/lYI/Cxo=" crossorigin="anonymous"></script>
<script type="">

  const select = (el, all = false) => {
    el = el.trim()
    if (all) {
      return [...document.querySelectorAll(el)]
    } else {
      return document.querySelector(el)
    }
  }


</script>


<?php $__env->stopSection(); ?>
<?php echo $__env->make('backend.layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/u511712962/domains/mindufin.site/public_html/resources/views/backend/bills/view_users.blade.php ENDPATH**/ ?>