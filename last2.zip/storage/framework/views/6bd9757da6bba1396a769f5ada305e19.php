

  <table class="table datatable" id='tbl_exporttable_to_xls'>
    <thead>
      <tr>
        <th scope="col">#</th>
        <th scope="col">First Name</th>
        <th scope="col">Last Name</th>
        <th scope="col">Email</th>
        <th scope="col">Phone No.</th>
        <th scope="col">Blood Group</th>
        <th scope="col">DoB</th>
        <th scope="col">Address</th>
        <th scope="col">State</th>
        <th scope="col">District</th>
        <th scope="col">Pincode</th>
        <th scope="col">Designation</th>
        <th scope="col">Created At</th>
        <th scope="col">Status</th>
        <th scope="col">Action</th>

      </tr>
    </thead>
    <tbody>

      <?php if(!empty($records)): ?>
      <?php $i="1"; ?>
      <?php $__currentLoopData = $records; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $row): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
      <tr>
        <th scope="row"><?php echo e($i++); ?></th>
        <td><?php echo e($row->firstName); ?></td>
        <td><?php echo e($row->lastName); ?></td>
        <td><?php echo e($row->email); ?></td>
        <td><?php echo e($row->phone); ?></td>
        <td><?php echo e($row->bloodGroup ? $row->bloodGroup : 'N/A'); ?></td>
        <td><?php echo e($row->dob ? $row->dob : 'N/A'); ?></td>
        <td><?php echo e($row->address ? $row->address : 'N/A'); ?></td>
        <td><?php echo e($row->state ? $row->state : 'N/A'); ?></td>
        <td><?php echo e($row->district ? $row->district : 'N/A'); ?></td>
        <td><?php echo e($row->pincode ? $row->pincode : 'N/A'); ?></td>
        <td><?php echo e($row->designation ? $row->designation : 'N/A'); ?></td>
        <td><?php echo e(!empty($row->createdAt) ? date('Y-m-d', strtotime($row->createdAt)) : ''); ?></td>
        <td id="statusCell<?php echo e($row->id); ?>">
            <?php if($row->canGoLive): ?>
              <span class="badge bg-success">Active</span>
            <?php else: ?>
            <span class="badge bg-danger">InActive</span>
            <?php endif; ?>
          </td>
          <td>
            <div class="form-check form-switch  d-flex justify-center align-items-center w-100 h-100">
              <input class="form-check-input user-status-toggle" type="checkbox"  data-id="<?php echo e($row->id); ?>"   id="flexSwitchCheckDefault" <?php echo e($row->canGoLive ? 'checked' : ''); ?> >

              <a href="#" onClick="confirmation(<?php echo $row->id; ?>);" class="btn btn-danger rounded-pill ms-2" >Delete</a></td>
            </div>
          </td>
      </tr>
      <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
      <?php $i++; ?>
      <?php endif; ?>
    </tbody>


  </table>


  <script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>

<script>
    $(document).ready(function () {
        $('.user-status-toggle').change(function () {

            const id = $(this).data('id');
            const statusCell = $('#statusCell' + id);
            const status = $(this).prop('checked') ? 1 : 0;

            
            $.ajax({
                url: '/admin/update-user-status/' + id,
                type: 'GET',
                data: {
                    status: status
                },
                success: function (response) {

                    if (status === 1) {
                        statusCell.html('<span class="badge bg-success">Active</span>');
                    } else {
                        statusCell.html('<span class="badge bg-danger">InActive</span>');
                    }
                    
                },
                error: function (xhr, status, error) {
                    console.error('Error:', error);
                }
            });
        });
    });

    function confirmation(value){
         event.preventDefault();
            alertify.confirm("Are you Sure you Want to Delete?", function (e) {
          if (e) {
             window.location.href = "<?php echo e(url('')); ?>/admin/delete-user/"+value;
           }
          else{
           }
         });
      }

</script>
<?php /**PATH F:\xampp8.2\htdocs\mns\resources\views/backend/users/view_users_data.blade.php ENDPATH**/ ?>