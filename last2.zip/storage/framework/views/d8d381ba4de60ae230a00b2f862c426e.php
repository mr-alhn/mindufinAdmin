<?php $__env->startSection('main-content'); ?>
<main id="main" class="main">
    <div class="pagetitle">
        <h1><?php echo e($title ? $title : "Add New Job Updates"); ?></h1>
    </div>
    <section class="section">
        <div class="row">
            <div class="col-lg-1"></div>
            <div class="col-lg-10">
                <div class="card">
                    <div class="card-body">
                        <h5 class="card-title"> </h5>
                        <form action="<?php echo e(!empty($record) ? url('admin/update-job-updates') : url('admin/add-job-updates')); ?>" method="POST" enctype="multipart/form-data" class="row g-3">

                    
                        <?php echo csrf_field(); ?>
                            <input type="hidden" name="id" value="<?= !empty($record['id']) ? $record['id'] : '' ?>">
                            
                            <div class="col-12">
                                <label for="jobtitle" class="form-label">Title</label>
                                <input type="text" required name="title" class="form-control" placeholder="Enter Title" value="<?= !empty($record['title']) ? $record['title'] : '' ?>">
                            </div>
                            <br>
                            <div class="col-12">
                                <label for="jobtitle" class="form-label">Duration</label>
                                <input type="text" required name="duration" class="form-control" placeholder="Enter Duration" value="<?= !empty($record['duration']) ? $record['duration'] : '' ?>">
                            </div>
                            <br>
                            <div class="col-12">
                                <label for="jobtitle" class="form-label">Location</label>
                                <input type="text" required name="location" class="form-control" placeholder="Enter Location" value="<?= !empty($record['location']) ? $record['location'] : '' ?>">
                            </div>
                            <br>
                            <div class="col-12">
                                <label for="jobtitle" class="form-label">Compnay Name</label>
                                <input type="text" required name="companyName" class="form-control" placeholder="Enter Company Name" value="<?= !empty($record['companyName']) ? $record['companyName'] : '' ?>">
                            </div>
                            <br>
                            <div class="col-12">
                                <label for="jobtitle" class="form-label">Require Post</label>
                                <input type="text" required name="requiredPost" class="form-control" placeholder="Enter Require Post" value="<?= !empty($record['requiredPost']) ? $record['requiredPost'] : '' ?>">
                            </div>
                            <br>
                            <div class="col-12">
                                <label for="jobtitle" class="form-label">Last Date</label>
                                <input type="date" required name="lastDate" class="form-control" placeholder="Select Last Date" value="<?= !empty($record['lastDate']) ? date('Y-m-d', strtotime($record['lastDate'])) : '' ?>">
                            </div>
                            <br>
                            <div class="col-12">
                                <label for="jobtitle" class="form-label">About Compnay</label>
                                <input type="text" required name="aboutCompany" class="form-control" placeholder="Enter About Company" value="<?= !empty($record['aboutCompany']) ? $record['aboutCompany'] : '' ?>">
                            </div>
                            <br>
                            <div class="col-12">
                                <label for="jobtitle" class="form-label">About Job </label>
                                <input type="text" required name="aboutJob" class="form-control" placeholder="Enter About Job" value="<?= !empty($record['aboutJob']) ? $record['aboutJob'] : '' ?>">
                            </div>
                            <br>
                            <div class="col-12">
                                <label for="jobtitle" class="form-label">Salary</label>
                                <input type="text" required name="salary" class="form-control" placeholder="Enter Salary" value="<?= !empty($record['salary']) ? $record['salary'] : '' ?>">
                            </div>
                            <br>
                                
                                <div class="col-12">
                                    <label for="jobtitle" class="form-label">Pincode</label>
                                    
                                    <select class="form-select dynamic-tags" required name="pincode[]"  multiple>
                                    <?php if(!empty($record)){ ?>
                                    <?php $__currentLoopData = $record['pincode']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $pincode): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <option value="<?php echo e($pincode); ?>"  selected ><?php echo e($pincode); ?></option>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    <?php } ?>
                                    </select>

                                </div>

                            <div class="text-center"><button type="submit" class="btn btn-primary">Submit</button> </div>
                        </form>
                    </div>
                </div>
            </div>
            <div class="col-lg-1"></div>
        </div>
    </section>
</main>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('backend.layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH F:\xampp8.2\htdocs\mns\resources\views/backend/job_updates/add_job_updates.blade.php ENDPATH**/ ?>