<?php $__env->startSection('main-content'); ?>

  <main id="main" class="main">
    <section class="section">
      <div class="row">
        

        <div class="col-lg-12">
          <div class="card">
            <div class="card-body">
              <h5 class="card-title">View All Complaints</h5>
              <button class='btn btn-success' onclick="ExportToExcel('xlsx')">Export to excel</button>
              <table class="table datatable" id='tbl_exporttable_to_xls'>
                <thead>
                  <tr>
                    <th scope="col">#</th>
                    <th scope="col">Name</th>
                    <th scope="col">Phone</th>
                    <th scope="col">Description</th>
                    <th scope="col">Complaint Id</th>
                    <th scope="col">Status</th>
                    <th scope="col">Action</th>
                  </tr>
                </thead>
                <tbody>
                  <?php if(!empty($records)): ?>
                  <?php $i="1"; ?>
                  <?php $__currentLoopData = $records; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $row): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                  <tr>
                    <th scope="row"><?php echo e($i++); ?></th>
                    <td><?php echo e($row->name); ?></td>
                    <td><?php echo e($row->phone); ?></td>
                    <td><?php echo e($row->description); ?></td>
                    <td><?php echo e($row->complaintId); ?></td>
                    <td id="statusCell<?php echo e($row->id); ?>">
                      <?php if($row->status == 'RESOLVED'): ?>
                        <span class="badge bg-success">Resolved</span>
                      <?php else: ?>
                      <span class="badge bg-warning">ACTIVE</span>
                      <?php endif; ?>
                    </td>
                    <td>
                      <div class="form-check form-switch d-flex justify-content-center align-items-center">
                        <input class="form-check-input user-status-toggle" type="checkbox"  data-id="<?php echo e($row->id); ?>"   id="flexSwitchCheckDefault" <?php echo e($row->status == "RESOLVED" ? 'checked' : ''); ?> >

                        <a href="#" onClick="confirmation(<?php echo $row->id; ?>);" class="ms-2 btn btn-danger rounded-pill" >Delete</a>
                       
                      </div>
                      
                    </td>

                  </tr>
                  <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                  <?php $i++; ?>
                  <?php endif; ?>
                </tbody>


              </table>

            </div>
          </div>
        </div>
      </div>
    </section>
  </main>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('script'); ?>
<script type="text/javascript" src="https://unpkg.com/xlsx@0.15.1/dist/xlsx.full.min.js"></script>
<script>

  function ExportToExcel(type, fn, dl) {
      var elt = document.getElementById('tbl_exporttable_to_xls');
      var wb = XLSX.utils.table_to_book(elt, { sheet: "sheet1" });
      return dl ?
          XLSX.write(wb, { bookType: type, bookSST: true, type: 'base64' }) :
          XLSX.writeFile(wb, fn || ('complaints.' + (type || 'xlsx')));
  }

</script>
<script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
<script>
    $(document).ready(function () {
        $('.user-status-toggle').change(function () {


            const id = $(this).data('id');
            const statusCell = $('#statusCell' + id);
            const status = $(this).prop('checked') ? 'RESOLVED' : 'ACTIVE';

            
            $.ajax({
                url: '/admin/update-complaints-status/' + id,
                type: 'GET',
                data: {
                    status: status
                },
                success: function (response) {
                    // console.log(response);

                    if (status === 'RESOLVED') {
                        statusCell.html('<span class="badge bg-success">RESOLVED</span>');
                    } else {
                        statusCell.html('<span class="badge bg-warning">ACTIVE</span>');
                    }
                    
                },
                error: function (xhr, status, error) {
                    console.error('Error:', error);
                }
            });
        });
    });
</script>

<script type="text/javascript">
  function confirmation(value){
         event.preventDefault();
            alertify.confirm("Are you Sure you Want to Delete?", function (e) {
          if (e) {
             window.location.href = "<?php echo e(url('')); ?>/admin/delete-complaint/"+value;
           }
          else{
           }
         });
      }
</script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('backend.layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH F:\xampp8.2\htdocs\mns\resources\views/backend/complaints/view_complaints.blade.php ENDPATH**/ ?>