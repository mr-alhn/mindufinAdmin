<?php $__env->startSection('main-content'); ?>
<main id="main" class="main">
    <div class="pagetitle">
        <h1><?php echo e($title ? $title : "Profile"); ?></h1>
    </div>
    <section class="section">
        <div class="row">
            <div class="col-lg-1"></div>
            <div class="col-lg-10">
                <div class="card">
                    <div class="card-body">
                        <h5 class="card-title"> </h5>
                        <form action="<?php echo e(url('admin/update-profile')); ?>" method="POST" enctype="multipart/form-data" class="row g-3">

                        <?php echo csrf_field(); ?>
                            <div class="col-12">
                                <label for="jobtitle" class="form-label">Name</label>
                                <input type="text" required name="name" class="form-control" id="page" placeholder="Enter Name" value="<?= !empty(session('admin')->name) ? session('admin')->name : '' ?>">
                            </div>
                            <!-- <br> -->
<!--                             <div class="col-12">
                                <label for="jobtitle" class="form-label">Email</label>
                                <input type="text" required name="email" class="form-control" id="page" placeholder="Enter Email" value="<?= !empty(session('admin')->email) ? session('admin')->email : '' ?>">
                            </div>
                            <br>
                            <div class="col-12">
                                <label for="jobtitle" class="form-label">Phone</label>
                                <input type="text" required name="phone" class="form-control" id="page" placeholder="Enter Phone" value="<?= !empty(session('admin')->phone) ? session('admin')->phone : '' ?>">
                            </div> -->
                            <!-- <br> -->
                            <div class="col-12">
                                <label for="jobtitle" class="form-label">Current Password</label>
                                <input type="password"  name="oldPassword" class="form-control" id="page" placeholder="Enter Current Password" >
                            </div>
                            <div class="col-12">
                                <label for="jobtitle" class="form-label">New Password</label>
                                <input type="password" name="password" class="form-control" id="page" placeholder="Enter New Password" >
                            </div>
                            <br>
                            
                            <div class="text-center"><button type="submit" class="btn btn-primary">Submit</button> </div>
                        </form>
                    </div>
                </div>
            </div>
            <div class="col-lg-1"></div>
        </div>
    </section>
</main>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('backend.layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH F:\xampp8.2\htdocs\mindufin\resources\views/backend/profile/index.blade.php ENDPATH**/ ?>