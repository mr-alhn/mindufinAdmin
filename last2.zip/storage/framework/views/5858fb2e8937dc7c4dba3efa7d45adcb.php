<?php $__env->startSection('main-content'); ?>
  <main id="main" class="main">
    <section class="section">
      <div class="row">
        
      
        <div class="col-lg-12">
          <div class="card">
            <div class="card-body">
              <h5 class="card-title"><?php echo e($title); ?></h5>

              <div class="text-center text-bold" ><b id="loader"></b></div>
              
              <table class="table datatable" id='tbl_exporttable_to_xls'>
                <thead>
                  <tr>
                    <th scope="col">#</th>
                    <th scope="col">UserId</th>
                    <th scope="col">Month</th>
                    <th scope="col">Year</th>
                    <th scope="col">Doc Name</th>
                    <th scope="col">File</th>
                    <th scope="col">Date</th>
                    <th scope="col">Message</th>

                  </tr>
                </thead>
                <tbody>

                  <?php if(!empty($records)): ?>
                  <?php $i="1"; ?>
                  <?php $__currentLoopData = $records; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $row): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                  <tr>
                    <th scope="row"><?php echo e($i++); ?></th>
                    <td><?php echo e($row->userId); ?></td>
                    <td><?php echo e($row->month); ?></td>
                    <td><?php echo e($row->year); ?></td>
                    <td><?php echo e($row->docName); ?></td>
                    <td>
                      <?php if(!empty($row->files)): ?>
                          <a href="<?php echo e(env('API_URL').$row->files[0]); ?>" download>Click Here to View</a>
                      <?php endif; ?>
                    </td>
                    <td><?php echo e($row->date); ?></td>
                    <td><?php echo e($row->message); ?></td>
                   
                  </tr>
                  <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                  <?php $i++; ?>
                  <?php endif; ?>
                </tbody>


              </table>
              
            </div>
          </div>
         
        </div>
      </div>
    </section>
  </main>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('script'); ?>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('backend.layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/u511712962/domains/mindufin.site/public_html/resources/views/backend/bills/view_bill_records.blade.php ENDPATH**/ ?>