<?php
return [
    'title' => 'MindUfin',  // This appears to be a brand name, so it's left untranslated
    'login' => 'Log in op uw account',
    'login_subheading' => 'Voer uw gebruikersnaam en wachtwoord in om in te loggen',
    'sign_out'	=> 'Uitloggen'
];