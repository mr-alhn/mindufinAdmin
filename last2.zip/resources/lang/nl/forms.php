<?php
return [
    'name'              => 'Naam',
    'email'             => 'E-mail',
    'phone'             => 'Telefoon',
    'password'          => 'Wachtwoord',
    'avatar'            => 'Avatar',
    'title'             => 'Titel',
    'body'              => 'Inhoud',
    'enter_email'       => 'Voer e-mailadres in',
    'enter_password'    => 'Voer wachtwoord in',
    'login_button'      => 'Inloggen',
    'current_password'  => 'Huidig wachtwoord',
    'new_password'      => 'Nieuw wachtwoord',
    'submit'            => 'Versturen',
];