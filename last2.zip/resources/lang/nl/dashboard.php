<?php
return [
    'users'             => 'Gebruikers',
    'users_this_month'  => 'Gebruikers deze maand',
    'bills'             => 'Facturen',
    'bills_this_year'   => 'Facturen dit jaar',
    'bills_this_month'  => 'Facturen deze maand',
    'bills_today'       => 'Facturen vandaag',
    'copyright'         => 'Auteursrecht',
    'all_rights'        => 'Alle rechten voorbehouden',
];