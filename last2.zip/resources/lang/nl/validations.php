<?php

return [
    'email' 		 => 'Email',
    'password' 		 => 'Password',
    'enter_email' 	 => 'Enter Email',
    'enter_password' => 'Enter Password',
    'login_button'	 => 'Login',
];