<?php
return [
    'dashbaord'         => 'Dashboard', 
    'users'             => 'Gebruikers',
    'create_user'       => 'Gebruiker aanmaken',
    'view_users'        => 'Gebruikers bekijken',
    'reports'           => 'Rapporten',
    'view_reports'      => 'Rapporten bekijken',
    'view_bills' 	    => 'Facturen bekijken',
    'notification'      => 'Melding',
    'send_notification' => 'Melding versturen',
    'profile'           => 'Profiel',
];