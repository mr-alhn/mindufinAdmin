<?php

return [
    'title' => 'MindUfin',
    'login' => 'Login to Your Account',
    'login_subheading' => 'Enter your username & password to login',
    'sign_out'	=> 'Sign Out'
];