<?php

return [
    'users'   			=> 'Users',
    'users_this_month' 	=> 'Users This Month',
    'bills' 	  		=> 'Bills',
    'bills_this_year'	=> 'Bills This Year',
    'bills_this_month'	=> 'Bills This Month',
    'bills_today'		=> 'Bills Today',
    'copyright'			=> 'Copyright',
    'all_rights'		=> 'All Rights Reserved',
    
];