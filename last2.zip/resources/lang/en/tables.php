<?php

return [
	'id'		=> 'id',
	'user_id'		=> 'UserId',
    'name' 		 => 'Name',
    'email' 		 => 'Email',
    'phone_no' 		 => 'Phone No.',
    'image' 	 => 'Image',
    'created_at' => 'Created At',
    'action'	 => 'Action',
    'chat_with_user'	=> 'Chat with User',
    'export'	=> 'Export To Excel',
    'attachment'	=> 'Attachment',
    'date'	=> 'Date',
    'message'	=> 'Message',
    'status'	=> 'Status',
    'download_report'	=> 'Download Report',
    'resolved'	=> 'Resolved',
    'rejected'	=> 'Rejected',
    'pending'	=> 'Pending',
    'delete'	=> 'Delete',
];