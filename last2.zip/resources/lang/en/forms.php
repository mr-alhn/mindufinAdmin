<?php

return [
    'name'			  => 'Name',
    'email' 		  => 'Email',
    'phone' 		  => 'Phone',
    'password' 		  => 'Password',
    'avatar' 		  => 'Avatar',
    'title' 		  => 'Title',
    'body' 		  => 'Body',
    'enter_email' 	  => 'Enter Email',
    'enter_password'  => 'Enter Password',
    'login_button'	  => 'Login',
    'current_password'=> 'Current Password',
    'new_password'	  => 'New Password',
    'submit'		  => 'Submit',

];