<?php

return [
    'dashbaord'   	   => 'Dashboard',
    'users' 	  	   => 'Users',
    'create_user' 	   => 'Create User',
    'view_users' 	   => 'View Users',
    'reports' 	  	   => 'Reports',
    'view_bills' 	   => 'View Bills',
    'view_reports' 	   => 'View Reports',
    'notification'	   => 'Notification',
    'send_notification'=> 'Send Notification',
    'profile'	  	   => 'Profile',
];