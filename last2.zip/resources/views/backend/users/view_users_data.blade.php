

  <table class="table datatable" id='tbl_exporttable_to_xls'>
    <thead>
      <tr>
        <th scope="col">#</th>
        <th scope="col">{{__('tables.user_id')}}</th>
        <th scope="col">{{__('tables.name')}}</th>
        <th scope="col">{{__('tables.email')}}</th>
        <th scope="col">{{__('tables.phone_no')}}</th>
        <th scope="col">{{__('tables.image')}}</th>
        <th scope="col">{{__('tables.created_at')}}</th>
        <th scope="col">{{__('tables.action')}}</th>

      </tr>
    </thead>
    <tbody>

      @if(!empty($records))
      @php $i="1"; @endphp
      @foreach($records as $row)
      <tr>
        <th scope="row">{{$i++}}</th>
        <td>{{$row->userId}}</td>
        <td>{{$row->name}}</td>
        <td>{{$row->email}}</td>
        <td>{{$row->phone}}</td>
        <td><img widh="200" height="80" src="{{env('API_URL').'/'.$row->avatar}}"></td>
        <td>{{!empty($row->createdAt) ? date('Y-m-d', strtotime($row->createdAt)) : '' }}</td>
        <td>
          <div class="d-flex align-items-center jsutify-content-center">
            <a href="{{url('admin/user/chat/'.$row->id)}}" class="btn btn-warning">{{__('tables.chat_with_user')}}</a>
            <a href="{{url('admin/user-detail/'.$row->id)}}" class="btn btn-primary"><i class="bi bi-pencil"></i></a>
            </div>
        </td>
                          
          
      </tr>
      @endforeach
      @php $i++; @endphp
      @endif
    </tbody>


  </table>

