@extends('backend.layouts.admin')
@section('main-content')
<main id="main" class="main">
    <div class="pagetitle">
        <h1>{{ $title ? $title : __('sidebar.create_user')}}</h1>
    </div>
    <section class="section">
        <div class="row">
            <div class="col-lg-1"></div>
            <div class="col-lg-10">
                <div class="card">
                    <div class="card-body">
                        <h5 class="card-title"> </h5>

                        <form action="{{ !empty($user) ? url('admin/update-user') : url('admin/create-user') }}" method="POST" enctype="multipart/form-data" class="row g-3">

                        @csrf
                            @if(!empty($user))
                            <input type="hidden" name="id" value="{{$user->id}}">
                                <div class="col-12">
                                    <label for="jobtitle" class="form-label">{{__('forms.new_password')}}</label>
                                    <input type="password" name="newPassword" required="" class="form-control" id="page" placeholder="Enter Password" >
                                </div>
                            
                            @else
                                
                                <div class="col-12">
                                    <label for="jobtitle" class="form-label">{{__('forms.name')}}</label>
                                    <input type="text" required name="name" class="form-control" id="page" placeholder="Enter {{__('forms.name')}}" >
                                </div>
                                <br>
                                <div class="col-12">
                                    <label for="jobtitle" class="form-label">{{__('forms.email')}}</label>
                                    <input type="text" required name="email" class="form-control" id="page" placeholder="Enter {{__('forms.email')}}" >
                                </div>
                                <br>
                                <div class="col-12">
                                    <label for="jobtitle" class="form-label">{{__('forms.phone')}}</label>
                                    <input type="text" required name="phone" class="form-control" id="page" placeholder="Enter {{__('forms.phone')}}" >
                                </div>
                                <br>
                                <div class="col-12">
                                    <label for="jobtitle" class="form-label">{{__('forms.password')}}</label>
                                    <input type="password" name="password" class="form-control" id="page" placeholder="Enter {{__('forms.password')}}" >
                                </div>
                                <br>
                                <div class="col-12">
                                    <label for="jobtitle" class="form-label">{{__('forms.avatar')}}</label>
                                    <input type="file"  name="image" class="form-control" id="page" >
                                </div>
                            @endif
                            
                            <div class="text-center"><button type="submit" class="btn btn-primary">{{__('forms.submit')}}</button> </div>
                        </form>
                    </div>
                </div>
            </div>
            <div class="col-lg-1"></div>
        </div>
    </section>
</main>
@endsection
