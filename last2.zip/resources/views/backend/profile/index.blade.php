@extends('backend.layouts.admin')
@section('main-content')
<main id="main" class="main">
    <div class="pagetitle">
        <h1>{{ $title ? $title : __('sidebar.profile')}}</h1>
    </div>
    <section class="section">
        <div class="row">
            <div class="col-lg-1"></div>
            <div class="col-lg-10">
                <div class="card">
                    <div class="card-body">
                        <h5 class="card-title"> </h5>
                        <form action="{{ url('admin/update-profile') }}" method="POST" enctype="multipart/form-data" class="row g-3">

                        @csrf
                            <div class="col-12">
                                <label for="jobtitle" class="form-label">{{__('forms.name')}}</label>
                                <input type="text" required name="name" class="form-control" id="page" placeholder="{{__('forms.name')}}" value="<?= !empty(session('admin')->name) ? session('admin')->name : '' ?>">
                            </div>
                            <!-- <br> -->
<!--                             <div class="col-12">
                                <label for="jobtitle" class="form-label">Email</label>
                                <input type="text" required name="email" class="form-control" id="page" placeholder="Enter Email" value="<?= !empty(session('admin')->email) ? session('admin')->email : '' ?>">
                            </div>
                            <br>
                            <div class="col-12">
                                <label for="jobtitle" class="form-label">Phone</label>
                                <input type="text" required name="phone" class="form-control" id="page" placeholder="Enter Phone" value="<?= !empty(session('admin')->phone) ? session('admin')->phone : '' ?>">
                            </div> -->
                            <!-- <br> -->
                            <div class="col-12">
                                <label for="jobtitle" class="form-label">{{__('forms.current_password')}}</label>
                                <input type="password"  name="oldPassword" class="form-control" id="page" placeholder="Enter {{__('forms.current_password')}}" >
                            </div>
                            <div class="col-12">
                                <label for="jobtitle" class="form-label">{{__('forms.new_password')}}</label>
                                <input type="password" name="password" class="form-control" id="page" placeholder="Enter {{__('forms.new_password')}}" >
                            </div>
                            <br>
                            
                            <div class="text-center"><button type="submit" class="btn btn-primary">{{__('forms.submit')}}</button> </div>
                        </form>
                    </div>
                </div>
            </div>
            <div class="col-lg-1"></div>
        </div>
    </section>
</main>
@endsection
