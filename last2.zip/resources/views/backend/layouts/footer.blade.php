<footer id="footer" class="footer">
    <div class="copyright">
      &copy; {{__('dashboard.copyright')}} <strong><span>{{__('auth.title')}}</span></strong>. {{__('dashboard.all_rights')}}
    </div>
  </footer>