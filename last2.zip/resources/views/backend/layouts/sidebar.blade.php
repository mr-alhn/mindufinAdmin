<aside id="sidebar" class="sidebar">
    <ul class="sidebar-nav" id="sidebar-nav">

      <li class="nav-item">
        <a class="nav-link {{ Request::is('admin/dashboard') ? '' : 'collapsed' }}" href="{{url('admin/dashboard')}}">
          <i class="bi bi-grid"></i>
          <span>{{__('sidebar.dashbaord')}}</span>
        </a>
      </li>
      
      <li class="nav-item">
        <a class="nav-link {{ Request::is('admin/users') || Request::is('admin/create-user') ? '' : 'collapsed' }}" data-bs-target="#users-nav" data-bs-toggle="collapse" href="#">
          <i class="bi bi bi-people"></i><span>{{__('sidebar.users')}}</span><i class="bi bi-chevron-down ms-auto"></i>
        </a>
        <ul id="users-nav" class="nav-content  {{ Request::is('admin/users') || Request::is('admin/create-user') ? '' : 'collapse' }}" data-bs-parent="#sidebar-nav">
          <li>
            <a href="{{url('admin/create-user')}}" class="{{ Request::is('admin/create-user') ? 'active' : '' }}">
              <i class="bi bi-circle"></i><span>{{__('sidebar.create_user')}}</span>
            </a>
          </li>
          <li>
            <a href="{{url('admin/users')}}" class="{{ Request::is('admin/users') ? 'active' : '' }}">
              <i class="bi bi-circle"></i><span>{{__('sidebar.view_users')}}</span>
            </a>
          </li>
        </ul>
      </li>


      <li class="nav-item">
        <a class="nav-link {{ Request::is('admin/reports') || Request::is('admin/bills') ? '' : 'collapsed' }}" data-bs-target="#reports-nav" data-bs-toggle="collapse" href="#">
          <i class="bi bi-folder"></i><span>{{__('sidebar.reports')}}</span><i class="bi bi-chevron-down ms-auto"></i>
        </a>
        <ul id="reports-nav" class="nav-content  {{ Request::is('admin/reports') || Request::is('admin/bills') ? '' : 'collapse' }}" data-bs-parent="#sidebar-nav">
         
          <li>
            <a href="{{url('admin/bills')}}" class="{{ Request::is('admin/bills') ? 'active' : '' }}">
              <i class="bi bi-circle"></i><span>{{__('sidebar.view_bills')}}</span>
            </a>
          </li>

          <li>
            <a href="{{url('admin/reports')}}" class="{{ Request::is('admin/reports') ? 'active' : '' }}">
              <i class="bi bi-circle"></i><span>{{__('sidebar.view_reports')}}</span>
            </a>
          </li>
        </ul>
      </li>
     

      <li class="nav-item">
        <a class="nav-link {{ Request::is('admin/send-notification') ? '' : 'collapsed' }}" data-bs-target="#noti-nav" data-bs-toggle="collapse" href="#">
          <i class="bi bi-bell-fill"></i><span>{{__('sidebar.notification')}}</span><i class="bi bi-chevron-down ms-auto"></i>
        </a>
        <ul id="noti-nav" class="nav-content  {{ Request::is('admin/send-notification') ? '' : 'collapse' }}" data-bs-parent="#sidebar-nav">
          <li>
            <a href="{{url('admin/send-notification')}}" class="{{ Request::is('admin/send-notification') ? 'active' : '' }}">
              <i class="bi bi-circle"></i><span>{{__('sidebar.send_notification')}}</span>
            </a>
          </li>
        </ul>
      </li>
      
      <li class="nav-item">
        <a class="nav-link {{ Request::is('admin/profile') ? '' : 'collapsed' }}" href="{{url('admin/profile')}}">
          <i class="bi bi-person-fill"></i>
          <span>{{__('sidebar.profile')}}</span>
        </a>
      </li>

      
      


      

    </ul>
  </aside>