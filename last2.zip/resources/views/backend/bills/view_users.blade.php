@extends('backend.layouts.admin')
@section('main-content')
  <main id="main" class="main">
    <section class="section">
      <div class="row">
        
      
        <div class="col-lg-12">
          <div class="card">
            <div class="card-body">
              <h5 class="card-title">{{__('sidebar.view_users')}}</h5>
              
               <div class="row">
                  
                    <!-- <div class="col-lg-12">
                      <button class='btn btn-success float-end me-2' onclick="ExportToExcel('xlsx')">{{__('tables.export')}}</button>
                    </div> -->
                </div>

              <div class="text-center text-bold" ><b id="loader"></b></div>
              
              <table class="table datatable" id='tbl_exporttable_to_xls'>
                <thead>
                  <tr>
                    <th scope="col">#</th>
                    <th scope="col">{{__('tables.user_id')}}</th>
                    <th scope="col">{{__('tables.name')}}</th>
                    <th scope="col">{{__('tables.email')}}</th>
                    <th scope="col">{{__('tables.phone_no')}}</th>
                    <th scope="col">{{__('tables.image')}}</th>
                    <th scope="col">{{__('tables.created_at')}}</th>
                    <!-- <th scope="col">{{__('tables.action')}}</th> -->

                  </tr>
                </thead>
                <tbody>

                  @if(!empty($records))
                  @php $i="1"; @endphp
                  @foreach($records as $row)
                  <tr>
                    <th scope="row">{{$i++}}</th>
                    <td><a href="{{url('admin/bills/'.$row->userId)}}">{{$row->userId}}</a></td>
                    <td>{{$row->name}}</td>
                    <td>{{$row->email}}</td>
                    <td>{{$row->phone}}</td>
                    <td><img widh="200" height="80" src="{{env('API_URL').'/'.$row->avatar}}"></td>
                    <td>{{!empty($row->createdAt) ? date('Y-m-d', strtotime($row->createdAt)) : '' }}</td>
                    <!-- <td>
                      <div class="d-flex align-items-center jsutify-content-center">
                        <a href="{{url('admin/user/chat/'.$row->id)}}" class="btn btn-warning">{{__('tables.chat_with_user')}}</a>
                        <a href="{{url('admin/user-detail/'.$row->id)}}" class="btn btn-primary"><i class="bi bi-pencil"></i></a>
                        </div>
                    </td> -->
                                      
                      
                  </tr>
                  @endforeach
                  @php $i++; @endphp
                  @endif
                </tbody>


              </table>
              

            </div>
          </div>
         
        </div>
      </div>
    </section>
  </main>
@endsection

@section('script')
<script type="text/javascript" src="https://unpkg.com/xlsx@0.15.1/dist/xlsx.full.min.js"></script>
<script>

  function ExportToExcel(type, fn, dl) {
      var elt = document.getElementById('tbl_exporttable_to_xls');
      var wb = XLSX.utils.table_to_book(elt, { sheet: "sheet1" });
      return dl ?
          XLSX.write(wb, { bookType: type, bookSST: true, type: 'base64' }) :
          XLSX.writeFile(wb, fn || ('Users.' + (type || 'xlsx')));
  }

</script>

<script src="https://code.jquery.com/jquery-3.7.1.min.js" integrity="sha256-/JqT3SQfawRcv/BIHPThkBvs0OEvtFFmqPF/lYI/Cxo=" crossorigin="anonymous"></script>
<script type="">

  const select = (el, all = false) => {
    el = el.trim()
    if (all) {
      return [...document.querySelectorAll(el)]
    } else {
      return document.querySelector(el)
    }
  }


</script>


@endsection