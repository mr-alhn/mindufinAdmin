@extends('backend.layouts.admin')
@section('main-content')
  <main id="main" class="main">
    <section class="section">
      <div class="row">
        
      
        <div class="col-lg-12">
          <div class="card">
            <div class="card-body">
              <h5 class="card-title">{{$title}}</h5>

              <div class="text-center text-bold" ><b id="loader"></b></div>
              
              <table class="table datatable" id='tbl_exporttable_to_xls'>
                <thead>
                  <tr>
                    <th scope="col">#</th>
                    <th scope="col">UserId</th>
                    <th scope="col">Month</th>
                    <th scope="col">Year</th>
                    <th scope="col">Doc Name</th>
                    <th scope="col">File</th>
                    <th scope="col">Date</th>
                    <th scope="col">Message</th>

                  </tr>
                </thead>
                <tbody>

                  @if(!empty($records))
                  @php $i="1"; @endphp
                  @foreach($records as $row)
                  <tr>
                    <th scope="row">{{$i++}}</th>
                    <td>{{$row->userId}}</td>
                    <td>{{$row->month}}</td>
                    <td>{{$row->year}}</td>
                    <td>{{$row->docName}}</td>
                    <td>
                      @if(!empty($row->files))
                          <a href="{{env('API_URL').$row->files[0]}}" download>Click Here to View</a>
                      @endif
                    </td>
                    <td>{{$row->date}}</td>
                    <td>{{$row->message}}</td>
                   
                  </tr>
                  @endforeach
                  @php $i++; @endphp
                  @endif
                </tbody>


              </table>
              
            </div>
          </div>
         
        </div>
      </div>
    </section>
  </main>
@endsection

@section('script')

@endsection