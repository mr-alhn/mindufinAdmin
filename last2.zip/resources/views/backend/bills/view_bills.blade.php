@extends('backend.layouts.admin')
@section('main-content')
<style>
    .month-link.disabled {
        pointer-events: none;
        opacity: 0.6;
    }
</style>
<main id="main" class="main">
  <section class="section">
    <div class="row">
      <div class="col-lg-12">
        <div class="card">
          <div class="card-body">
            <h5 class="card-title">View All Bills</h5>
            <div class="row">
              <div class="col-lg-12">
                <select class="form-control" id="yearSelect">
                  <option value="">Select Year</option>
                  <option value="2024">2024</option>
                  <option value="2023">2023</option>
                  <option value="2022">2022</option>
                  <option value="2021">2021</option>
                </select>
              </div>
            </div>             
          </div>
        </div>
      </div>
      @php
      $months = [
          'January', 'February', 'March', 'April', 'May', 'June',
          'July', 'August', 'September', 'October', 'November', 'December'
      ];
      @endphp
      @foreach($months as $index => $month)
      <div class="col-md-4">
        <a href="#" class="month-link" data-month="{{ $index + 1 }}" data-month-name="{{ $month }}">
          <div class="card">
            <div class="card-header text-center"><i class="bi bi-journals"></i></div>
            <div class="card-body p-0">
              <h5 class="card-title text-center">{{$month}}</h5>
            </div>
            <div class="card-footer text-center">
              <i class="bi bi-chevron-right"></i>
            </div>
          </div>
        </a>
      </div>
      @endforeach
    </div>
  </section>
</main>
@endsection

@section('script')
<script>
$(document).ready(function() {
    var year = null;
    var userId = {{ $userId }};

    $('#yearSelect').change(function() {
        year = $(this).val();
        if (year) {
            $('.month-link').removeClass('disabled');
        } else {
            $('.month-link').addClass('disabled');
        }
    });

    $('.month-link').click(function(e) {
        e.preventDefault();
        if (!year) {
            alertify.error('Please select a year first');
            return;
        }
        var month = $(this).data('month');
        var monthName = $(this).data('month-name');

        var url = '/admin/bill-details?year=' + encodeURIComponent(year) + 
                  '&month=' + encodeURIComponent(monthName) + 
                  '&userId=' + encodeURIComponent(userId);
        
        window.location.href = url;
    });

    // Initially disable all month links
    $('.month-link').addClass('disabled');
});
</script>
@endsection