@extends('backend.layouts.admin')
@section('main-content')
  <main id="main" class="main">
    <section class="section">
      <div class="row">
        
      
        <div class="col-lg-12">
          <div class="card">
            <div class="card-body">
              <h5 class="card-title">{{__('sidebar.view_reports')}}</h5>
              
               <div class="row">
                  
                    <div class="col-lg-12">
<!--                       <button class='btn btn-success float-end me-2' onclick="ExportToExcel('xlsx')">Export to excel</button> -->
                      <button class='btn btn-success float-end me-2' id="downloadButton">{{__('tables.download_report')}}
                    </button>
                    </div>
                </div>

              <div class="text-center text-bold" ><b id="loader"></b></div>
              
              <table class="table datatable" id='tbl_exporttable_to_xls'>
                <thead>
                  <tr>
                    <th scope="col">#</th>
                    <th scope="col">{{__('tables.user_id')}}</th>
                    <th scope="col">{{__('tables.name')}}</th>
                    <th scope="col">{{__('tables.email')}}</th>
                    <th scope="col">{{__('tables.phone_no')}}</th>
                    <th scope="col">{{__('tables.attachment')}}</th>
                    <th scope="col">{{__('tables.date')}}</th>
                    <th scope="col">{{__('tables.message')}}</th>
                    <th scope="col">{{__('tables.status')}}</th>
                    <th scope="col" class="text-center">{{__('tables.action')}}</th>

                  </tr>
                </thead>
                <tbody>

                  @if(!empty($records))
                  @php $i="1"; @endphp
                  @foreach($records as $row)
                  <tr>
                    <th scope="row">{{$i++}}</th>
                    <td>{{$row->userId}}</td>
                    <td>{{$row->name}}</td>
                    <td>{{$row->email}}</td>
                    <td>{{$row->number}}</td>
                    <td>
                      @if(!empty($row->attachment))
                        @php $i=1; @endphp
                        @foreach($row->attachment as $attachment)
                          <a href="{{env('API_URL').'/'.$attachment}}">{{__('tables.attachment')}} {{$i++}}</a>
                        @endforeach
                      @endif
                    </td>
                    <td>{{!empty($row->createdAt) ? date('Y-m-d', strtotime($row->createdAt)) : '' }}</td>
                    <td>
                      <a href="#" class="d-flex justify-content-center view-message" data-message="{{ $row->message }}">
                        <i class="bi bi-eye"></i>
                      </a>
                    </td>
                    <td id="statusCell{{ $row->id }}">
                        @if($row->status == 'resolved')
                            <span class="badge bg-success">{{__('tables.resolved')}}</span>
                        @elseif($row->status == 'rejected')
                            <span class="badge bg-danger">{{__('tables.rejected')}}</span>
                        @else
                            <span class="badge bg-warning">{{__('tables.pending')}}</span>
                        @endif
                    </td>
                    <td>
                      <div class="form-check form-switch d-flex justify-content-center align-items-center">
                       
                        <select class="status-toggle" data-id="{{ $row->id }}" data-old-value="{{ $row->status }}">
<!--                             <option value="pending" {{ $row->status == 'pending' ? 'selected' : '' }}>Pending</option> -->
                            <option value="resolved" {{ $row->status == 'resolved' ? 'selected' : '' }}>{{__('tables.resolved')}}</option>
                            <option value="rejected" {{ $row->status == 'rejected' ? 'selected' : '' }}>{{__('tables.rejected')}}</option>
                        </select>

                        <a href="#" onClick="confirmation(<?php echo $row->id; ?>);" class="ms-2 btn btn-danger rounded-pill" >{{__('tables.delete')}}</a>
                       
                      </div>
                      
                    </td>
                  </tr>
                  @endforeach
                  @php $i++; @endphp
                  @endif
                </tbody>


              </table>
              
            </div>
          </div>
         
        </div>
      </div>
    </section>
  </main>

  <!-- Message Modal -->
<div class="modal fade" id="messageModal" tabindex="-1" aria-labelledby="messageModalLabel" aria-hidden="true">
  <div class="modal-dialog">
    <div class="modal-content">
      <div class="modal-header">
        <h5 class="modal-title" id="messageModalLabel">Full Message</h5>
        <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
      </div>
      <div class="modal-body" id="messageModalBody">
        <!-- Message will be inserted here -->
      </div>
    </div>
  </div>
</div>
@endsection

@section('script')

<script src="https://code.jquery.com/jquery-3.7.1.min.js" integrity="sha256-/JqT3SQfawRcv/BIHPThkBvs0OEvtFFmqPF/lYI/Cxo=" crossorigin="anonymous"></script>
<script>

   document.getElementById('downloadButton').addEventListener('click', function () {
            window.location.href = "{{ route('admin.report.download') }}";
        });

</script>


<script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
<script>
    $(document).ready(function () {

      $('.view-message').click(function(e) {
          e.preventDefault();
          var message = $(this).data('message');
          $('#messageModalBody').text(message);
          $('#messageModal').modal('show');
      });

      $('.status-toggle').change(function () {
        const $this = $(this);
        const id = $this.data('id');
        const statusCell = $('#statusCell' + id);
        const status = $this.val();
        const oldValue = $this.data('old-value');

        alertify.confirm("Are you sure you want to update the status?", function (e) {
            if (e) {

                $.ajax({
                    url: '/admin/update-reports-status/' + id,
                    type: 'GET',
                    data: {
                        status: status
                    },
                    success: function (response) {
                        console.log(response);
                        if (status === 'resolved') {
                            statusCell.html('<span class="badge bg-success">{{__('tables.resolved')}}</span>');
                        } else if (status === 'rejected') {
                            statusCell.html('<span class="badge bg-danger">{{__('tables.rejected')}}</span>');
                        } else {
                            statusCell.html('<span class="badge bg-warning">{{__('tables.pending')}}</span>');
                        }
                        alertify.success(response.message);
                        $this.data('old-value', status);
                    },
                    error: function (xhr, status, error) {
                        var data = JSON.parse(xhr.responseText);
                        if (data.hasOwnProperty('errors')) {
                            var errorMessages = data.errors;
                            for (var prop in errorMessages) {
                                if (errorMessages.hasOwnProperty(prop)) {
                                    var messages = errorMessages[prop];
                                    messages.forEach(function (message) {
                                        alertify.error(message);
                                    });
                                }
                            }
                        } else {
                            alertify.error(data.message);
                        }
                        // Revert the select to its previous value
                        $this.val(oldValue);
                    }
                });
            } else {
                // User cancelled, revert the select to its previous value
                $this.val(oldValue);
            }
        });
    });
  });
</script>

<script type="text/javascript">
  function confirmation(value){
     event.preventDefault();
        alertify.confirm("Are you Sure you Want to Delete?", function (e) {
      if (e) {
         window.location.href = "{{url('')}}/admin/delete-report/"+value;
       }
      else{
       }
     });
  }
</script>

@endsection