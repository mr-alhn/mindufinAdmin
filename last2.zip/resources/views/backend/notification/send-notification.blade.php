@extends('backend.layouts.admin')
@section('main-content')
<main id="main" class="main">
    <div class="pagetitle">
        <h1>{{ $title ? $title : __('sidebar.send_notification')}}</h1>
    </div>
    <section class="section">
        <div class="row">
            <div class="col-lg-1"></div>
            <div class="col-lg-10">
                <div class="card">
                    <div class="card-body">
                        <h5 class="card-title"> </h5>
                        <form action="{{ url('admin/send-notification') }}" method="POST" enctype="multipart/form-data" class="row g-3">

                        @csrf
                            <div class="col-12">
                                <label for="jobtitle" class="form-label">{{__('forms.title')}}</label>
                                <input type="text" required name="title" class="form-control" id="page" placeholder="Enter {{__('forms.title')}}" value="<?= !empty($getForEdit['title']) ? $getJobForEdit['title'] : '' ?>">
                            </div>
                            <br>
                            <div class="col-12">
                                <label for="jobtitle" class="form-label">{{__('forms.body')}}</label>
                                <textarea  required name="body" class="form-control" placeholder="Enter {{__('forms.body')}}"></textarea>
                            </div>
                            <br>
                            
                            <div class="text-center"><button type="submit" class="btn btn-primary">{{__('forms.submit')}}</button> </div>
                        </form>
                    </div>
                </div>
            </div>
            <div class="col-lg-1"></div>
        </div>
    </section>
</main>
@endsection
