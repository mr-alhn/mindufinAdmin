<?php

use Illuminate\Support\Facades\Route;
use App\Http\Controllers\backend\ReportController;
use App\Http\Controllers\backend\UserController;
use App\Http\Controllers\backend\BillController;
use App\Http\Controllers\backend\AdminController;
use App\Http\Controllers\backend\SendNotificationController;

/*
|--------------------------------------------------------------------------
| Web Routes
|--------------------------------------------------------------------------
|
| Here is where you can register web routes for your application. These
| routes are loaded by the RouteServiceProvider and all of them will
| be assigned to the "web" middleware group. Make something great!
|
*/

Route::get('/', function () {
	// return view('welcome');
	return redirect()->route('admin.login');
});

Route::get('/clear-cache', function () {

	Artisan::call('route:clear');
	Artisan::call('config:clear');
	Artisan::call('view:clear');
	Artisan::call('optimize:clear');
	Artisan::call('cache:clear');
});

Route::group(['prefix' => 'admin'], function () {


	Route::group(['middleware' => 'admin.guest'], function () {

		Route::view('login', 'backend.login')->name('admin.login');

		Route::post('login', [AdminController::class, 'login'])->name('admin.auth');
	});

	Route::group(['middleware' => 'admin.auth'], function () {

		Route::get('dashboard', [AdminController::class, 'dashboard'])->name('admin.home');
		Route::get('logout', [AdminController::class, 'logout'])->name('admin.logout');

		// Profile
		Route::get('profile', [AdminController::class, 'profile'])->name('admin.profile');
		Route::post('update-profile', [AdminController::class, 'updateProfile'])->name('admin.update.profile');


		//Users
		Route::get('users', [UserController::class, 'index'])->name('admin.users');
		Route::get('get-users', [UserController::class, 'getUsers']);
		Route::get('create-user', [UserController::class, 'createUser'])->name('admin.create.user');
		Route::post('create-user', [UserController::class, 'store'])->name('admin.store.user');
		Route::get('user-detail/{id}', [UserController::class, 'detail'])->name('admin.user-detail');
		Route::post('update-user', [UserController::class, 'update']);
		
		//chat
		Route::get('user/chat/{id}', [UserController::class, 'chat'])->name('admin.user.chat');


		//Reports
		Route::get('reports', [ReportController::class, 'index'])->name('admin.reports');
		Route::get('/download-report', [ReportController::class, 'downloadReport'])->name('admin.report.download');
		Route::get('update-reports-status/{id}', [ReportController::class, 'updateStatus']);
		Route::get('delete-report/{id}', [ReportController::class, 'deleteReport']);


		// Bills
		Route::get('bills', [BillController::class, 'bills'])->name('admin.view.bills');
		Route::get('bills/{id}', [BillController::class, 'index'])->name('admin.bills');
		Route::get('bill-details', [BillController::class, 'billDetails'])->name('admin.bill.details');




		//Notification
		Route::get('send-notification', [SendNotificationController::class, 'index'])->name('admin.send-notification');
		Route::post('send-notification', [SendNotificationController::class, 'sendNotification']);


		
	});
});
