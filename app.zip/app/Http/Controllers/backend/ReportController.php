<?php

namespace App\Http\Controllers\backend;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;
use DB;
use App\Http\Requests;
use Illuminate\Support\Facades\File;
use Illuminate\Support\Str;
use Illuminate\Support\Facades\Storage;
use Illuminate\Support\Facades\Validator;
use ApiHelper;
use Illuminate\Support\Facades\Http;

class ReportController extends Controller
{


    public function index(Request $request)
    {
        $data['title'] = 'View Reports';

        $response = ApiHelper::apiRequest('report/all');
        $data = $response->original;
        if ($data->status == true && $response->status() == 200) {
            $data1['records'] = $data->reports;
         
        }

        return view('backend/reports/view_reports',$data1);
    }

   

    public function downloadReport()
    {
        // Your Bearer token
        $bearerToken = session('bearer_token');

        // Call the external API with the Bearer token
        $response = Http::withToken($bearerToken)->get(env('API_URL').'/report/export');

        // Check if the response status code is within the range of 200-299
        if ($response->successful()) {
            $data = $response->body();

            // Create a CSV file
            $fileName = 'report.csv';
            $headers = [
                'Content-type' => 'text/csv',
                'Content-Disposition' => 'attachment; filename=' . $fileName,
            ];

            // Return the response as a download
            return response($data, 200, $headers);
        } else {
            // Handle the error
            return redirect()->back()->withErrors(['msg' => 'Failed to fetch the report.']);
        }
    }

    public function updateStatus($id)
    {
        $status = request()->input('status');
        
        // Validate that the status is one of the allowed enum values
        if (!in_array($status, ['pending', 'resolved', 'rejected'])) {
            return response()->json(['error' => 'Invalid status'], 400);
        }

        $data['status'] = $status;
        $url = 'report/update/'.$id;
        $response = ApiHelper::apiRequest($url, 'PUT', $data);
        $data = $response->original;
        
        if($data->status == true && $response->status() == 200) {
            return response()->json(['message' => 'Status updated successfully'],200);
        } else {
            return response()->json(['message' => $data->message], 500);
        }
    }

    public function deleteReport($id)
    {
        $url = 'report/delete/'. $id;
        $res = ApiHelper::apiRequest($url, 'DELETE');
        $data = $res->original;
        if($data->status == true && $res->status() == 200) {
            return redirect()->route('admin.reports')->with('success', 'Report Deleted Successfully');
        }
        else {
            return redirect()->route('admin.reports')->with('error','Something went wrong.');
        }
    }
}