<?php

namespace App\Http\Controllers\backend;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;
use DB;
use App\Http\Requests;
use Illuminate\Support\Facades\File;
use Illuminate\Support\Str;
use Illuminate\Support\Facades\Storage;
use Illuminate\Support\Facades\Validator;
use ApiHelper;
use Illuminate\Pagination\LengthAwarePaginator;
use Illuminate\Support\Collection;

class UserController extends Controller
{


    public function index(Request $request)
    {
        $data['title'] = 'View Users';

        return view('backend/users/view_users',$data);
    }

    public function getUsers(Request $request)
    {
        if(!$request->ajax()){
            return response('', 405);
        }
      
        $url = 'user/all';
        $response = ApiHelper::apiRequest($url);

        $res = $response->original;

        if ($res->status == true && $response->status() == 200) {
            $allUsers = $res->users;

            // Check the selected option
            $selectedOption = $request->filter;

            switch ($selectedOption) {
                case 'all':

                    $data['records'] = $allUsers;
                    break;
              
                default:
                    $data['records'] = array();
                    break;
            }
        } else {
            $data['records'] = array();
        }

        $html = view('backend/users/view_users_data',$data)->render();
        return response()->json($html);

    }

    public function createUser(Request $request)
    {
        $data['title'] = 'Create User';

        return view('backend/users/create_user',$data);
    }

    public function store(Request $request)
    {

        $rules = array(
            'name'    => 'required',
            'email' => 'required',
            'phone' => 'required',
            'image' => 'required|mimes:jpeg,png,jpg,gif,svg',
            'password' => 'nullable|string|min:6',
        );
        $validator = Validator::make($request->all(), $rules);
        if($validator->fails()){
            return redirect()->back()->withErrors($validator->errors())->withInput();;
        }
        else {
            $validatedData = $validator->validated();
            $url = 'user/create';
            $response = ApiHelper::apiRequest($url, 'POST', $validatedData);
            $data = $response->original;
           
            if($data->status == true && $response->status() == 200) {

                $admin = session('admin');
                $admin->name = $validatedData['name'];
                $admin->email = $validatedData['email'];
                $admin->phone = $validatedData['phone'];
                session(['admin' => $admin]);

                return redirect()->route('admin.users')->with('success', $data->message);
            }
            else {
                return redirect()->route('admin.users')->with('error',$data->message);
            }
        }
    }
    
    public function chat(Request $request,$user_id){

        $data['user_id'] = $user_id;
        return view('backend/users/view_chat',$data);
    }

    public function detail($id)
    {
        $data1['title'] = 'Update User Password';
        $url = 'user/profile/' .$id;
        $response = ApiHelper::apiRequest($url);
        $data = $response->original;
        if($data->status == true && $response->status() == 200){
            
            $data1['user'] = $data->user;
            
        }

        return view('backend/users/create_user',$data1);
    }

    public function update(Request $request)
    {
        $rules = array(
            'newPassword'    => 'required',
            'id' => 'required'
        );
        $validator = Validator::make($request->all(), $rules);
        if($validator->fails()){
            return redirect()->back()->withErrors($validator->errors())->withInput();;
        }
        else {
            $validatedData = $validator->validated();
            $url = 'changePassword/'. $validatedData['id'].'/user';
            $response = ApiHelper::apiRequest($url, 'PUT', $validatedData);
            $data = $response->original;
            if($data->status == true && $response->status() == 200) {
                return redirect()->route('admin.users')->with('success', 'Password Update Successfully');
            }
            else {
                return redirect()->route('admin.users')->with('error', $data->message);
            }
        }
    }

}