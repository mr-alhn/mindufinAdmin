<?php

namespace App\Http\Controllers\backend;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;

use Illuminate\Support\Facades\Validator;
use Illuminate\Support\Facades\Http;
use ApiHelper;

class AdminController extends Controller
{
    public function login(Request $request)
    {

        $rules = array(
            'email'    => 'required',
            'password' => 'required',
        );
        $validator = Validator::make($request->all(), $rules);
        if ($validator->fails()) {
            return redirect()->back()->withErrors($validator->errors())->withInput();;
        } else {
            $response = ApiHelper::adminLogin($request);
            $data = $response->original;

            if ($data->status == true && $response->status() == 200) {

                session(['bearer_token'=>$data->token]);

                $response = ApiHelper::apiRequest('admin/me/1');
                $data = $response->original;

                if ($data->status == true && $response->status() == 200) {

                    session(['admin' => $data->admin]);

                    return redirect()->route('admin.home')->with('success', 'LoggedIn Successfully.');
                }
                else{
                    return redirect()->route('admin.login')->with('error', 'Try again!');
                }

            } else {
                return redirect()->route('admin.login')->with('error', 'Credentials do not match.');
            }
        }
    }

    public function dashboard(Request $request)
    {
        $data1['title'] = 'Dashboard';
        $response = ApiHelper::getDashboardData($request);
        $data = $response->original;
        if ($data->status == true && $response->status() == 200) {
            $data1['record'] = json_decode(json_encode($data), true);
        }

        return view('backend.dashboard', $data1);
    }


    public function logout(Request $request)
    {
        session()->forget('admin');
        session()->forget('bearer_token');
        return redirect()->route('admin.login');
    }

    public function profile(){

        $data1['title'] = 'Profile';
        $response = ApiHelper::apiRequest('admin/me/1');

        $data = $response->original;
        if ($data->status == true && $response->status() == 200) {
            $data1['record'] = json_decode(json_encode($data), true);
        }
        return view('backend.profile.index', $data1);

    }

    public function updateProfile(Request $request){

        $rules = array(
            'name'    => 'required',
            // 'email' => 'required',
            // 'phone' => 'required',
            'oldPassword' => 'nullable|required_with:password',
            'password' => 'nullable|string|min:6',
        );
        $validator = Validator::make($request->all(), $rules);
        if($validator->fails()){
            return redirect()->back()->withErrors($validator->errors())->withInput();;
        }
        else {
            $validatedData = $validator->validated();
            $url = 'admin/me/update';
            $response = ApiHelper::apiRequest($url, 'PUT', $validatedData);
            $data = $response->original;
           
            if($data->status == true && $response->status() == 200) {

                $admin = session('admin');
                $admin->name = $validatedData['name'];
                // $admin->email = $validatedData['email'];
                // $admin->phone = $validatedData['phone'];
                session(['admin' => $admin]);

                return redirect()->route('admin.profile')->with('success', $data->message);
            }
            else {
                return redirect()->route('admin.profile')->with('error',$data->message);
            }
        }
    }
}
