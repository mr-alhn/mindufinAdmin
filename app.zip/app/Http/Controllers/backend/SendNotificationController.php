<?php

namespace App\Http\Controllers\backend;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Validator;
use ApiHelper;

class SendNotificationController extends Controller
{
    public function index(Request $request)
    {
        $data['title'] = 'Send Notification';
        return view('backend/notification/send-notification',$data);
    }

    public function sendNotification(Request $request)
    {
        $rules = array(
            'title'    => 'required',
            'body' => 'required',
        );
        $validator = Validator::make($request->all(), $rules);
        if($validator->fails()){
            return redirect()->back()->withErrors($validator->errors())->withInput();;
        }
        else {
            $validatedData = $validator->validated();
            $url = 'sendNotification';
            $response = ApiHelper::apiRequest($url, 'POST', $validatedData);
            $data = $response->original;
            if($data->status == true && $response->status() == 200) {
                return redirect()->route('admin.send-notification')->with('success', $data->message);
            }
            else {
                return redirect()->route('admin.send-notification')->with('error','Something went wrong.');
            }
        }
    }


}