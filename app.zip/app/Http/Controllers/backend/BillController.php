<?php

namespace App\Http\Controllers\backend;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;
use DB;
use App\Http\Requests;
use Illuminate\Support\Facades\File;
use Illuminate\Support\Str;
use Illuminate\Support\Facades\Storage;
use Illuminate\Support\Facades\Validator;
use ApiHelper;
use Illuminate\Support\Facades\Http;

class BillController extends Controller
{


    public function index(Request $request,$id)
    {   
        $data['title'] = 'View Bills';
        $data['userId'] = $id;

        return view('backend/bills/view_bills',$data);
    }

    
    public function bills(Request $request){
        

        $data1['title'] = 'View Data';
        $url = 'user/all';
        $response = ApiHelper::apiRequest($url);
        $data = $response->original;
        if ($data->status == true && $response->status() == 200) {

            $data1['records'] = $data->users;
         
        }

        return view('backend/bills/view_users',$data1);
    }   

    public function billDetails(Request $request){

        $userId = $request->userId;
        $year = $request->year;
        $month = $request->month;
        

        $data1['title'] = 'View Bill of '.$month;
        $url = 'bill/'.$userId.'/'.$month.'/'.$year;
        $response = ApiHelper::apiRequest($url);
        $data = $response->original;
        if ($data->status == true && $response->status() == 200) {

            $data1['records'] = $data->bills;
         
        }

        return view('backend/bills/view_bill_records',$data1);
    }
}