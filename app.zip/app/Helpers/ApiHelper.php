<?php

use Illuminate\Support\Facades\Http;

class ApiHelper{

	public static function adminLogin($request){
		$response = Http::withHeaders([
            'Content-Type' => 'application/json',
            // 'Authorization' => 'Bearer ' . env('BEARER_TOKEN')
        ])
            ->post(env('API_URL').'/admin/login', [
                "email" => $request->email,
                "password" => $request->password
            ]);
        $result = json_decode($response->body());
        return response()->json($result);
	}

    public static function getDashboardData($request){
		$response = Http::withHeaders([
            'Content-Type' => 'application/json',
        ])
            ->get(env('API_URL').'/dashboard', [
                // "page" => $request->get('page'),
                // "pageSize" => config('settings.per_page')
            ]);
        $result = json_decode($response->body());
        return response()->json($result);
	}

	public static function getAllUsers($request){
		$response = Http::withHeaders([
            'Content-Type' => 'application/json',
        ])
            ->get(env('API_URL').'/users', [
                // "page" => $request->get('page'),
                // "pageSize" => config('settings.per_page')
            ]);
        $result = json_decode($response->body());
        return response()->json($result);
	}

    public static function uploadFile($data=[]){


        $defaultHeaders = ['Authorization' => 'Bearer ' . session('bearer_token')];
        $headers = [];
        $headers = array_merge($defaultHeaders, $headers);

        $response = Http::withHeaders($headers);

        if (!empty($data['image'])) {
            $response->attach('file', file_get_contents($data['image']->getRealPath()), $data['image']->getClientOriginalName());
            unset($data['image']);
        }

        $response = $response->post(env('API_URL') . '/upload');

        $result = json_decode($response->body());
        //  echo "<pre>";
        // print_r($result);die();
        return response()->json($result);
    }

    public static function apiRequest($url, $method = 'GET', $data = [], $headers = [])
    {
        $defaultHeaders = ['Authorization' => 'Bearer ' . session('bearer_token')];

        $headers = array_merge($defaultHeaders, $headers);

        $response = Http::withHeaders($headers);
        
        
        if ($method === 'DELETE') {
            $response = $response->delete(env('API_URL') . '/' . $url);
        } else {
            if (!empty($data['images'])) {

                $images['images'] = $data['images'];

                if(is_array($data['images'])){

                    foreach ($data['images'] as $file) {

                        $uploaddefaultHeaders = ['Authorization' => 'Bearer ' . env('BEARER_TOKEN')];
                        $uploadheaders = [];
                        $uploadheaders = array_merge($uploaddefaultHeaders, $uploadheaders);

                        $uploadresponse = Http::withHeaders($uploadheaders);

                            // foreach ($data['images'] as $file) {
                            //     $response->attach('file', file_get_contents($file->getRealPath()), $file->getClientOriginalName());
                            // }
                            $uploadresponse->attach('file', file_get_contents($file->getRealPath()), $file->getClientOriginalName());
                        
                        

                        $uploadresponse = $uploadresponse->post(env('API_URL') . '/upload');

                        $result = json_decode($uploadresponse->body());

                        $res =  response()->json($result);
                        $imagesdata = $res->original;
                        
                        $imageUrls[] = $imagesdata->fileUrl;
                    }

                    $data['images'] = $imageUrls;
                }
                else{


                    $res = ApiHelper::uploadFile($images);
                    $imagesdata = $res->original;
                    $data['images'] = [$imagesdata->fileUrl];
                }
                
                

                // unset($data['images']);
            }
            if (!empty($data['image'])) {
                
                $image['image'] = $data['image'];
                $res = ApiHelper::uploadFile($image);
                $imagedata = $res->original;
                $data['avatar'] = $imagedata->fileUrl;  

            }
      

            
            // echo "<pre>";
            // print_r($data);die();
            $response = $response->$method(env('API_URL') . '/' . $url, $data);
        }

        $result = json_decode($response->body());
            //         echo "<pre>";
            // print_r($result);die();
        return response()->json($result);
    }

    public static function roles(){

        return [

            'admin','users','reel','news','video','gallery','leader-updates','job-updates','complaints','city','notification','banner','popup'
        ];
    }

}