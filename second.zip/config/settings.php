<?php

return [

	'title' 	=> 'MindUfin',
	'per_page'  => 25,
	// 'bearer_token' => ''

];




?>